#!/usr/bin/env python
import sys, os.path
assert __name__ == '__main__'

if len(sys.argv) < 2:
	print "Usage: %s *GB*.t" % (os.path.basename(sys.argv[0]))
	sys.exit(0)

if sys.argv[1] != '-':
	f = open(sys.argv[1], 'r')
else:
	f = sys.stdin
lastrow = None
d = {}
F = lambda a, b: (ord(a) - 0xA0) * 100 + (ord(b) - 0xA0)
for line in f:
	line = line.rstrip()
	if line and line[0].isdigit():
		assert line[1].isdigit()
		lastrow = int(line[:2]) * 100
		lastcell = 0
	elif lastrow is None:
		continue
	count = 0
	lastch = None
	for c in line:
		if ord(c) < 0x80:
			assert c == ' ' or c.isdigit()
		else:
			if count & 1 == 0:
				lastch = c
			else:
				d[lastrow+ lastcell+ (count>>1)] = F(lastch, c)
		count += 1
	lastcell += 20
f.close()
euc = lambda c: chr(c / 100 + 0xA0) + chr(c % 100 + 0xA0)
for code in sorted(d.iterkeys()):
	#print '%04d\t%04d' % (code, d[code])
	print '%s\t%s' % (euc(code), euc(d[code]))
