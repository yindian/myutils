#!/usr/bin/env python
import sys, os.path
assert __name__ == '__main__'

if len(sys.argv) < 3:
	print "Usage: %s Uni2XX charsetIDs" % (os.path.basename(sys.argv[0]))
	sys.exit(0)

d = {}
for c in sys.argv[2]:
	d[c] = []
dd = {}
if sys.argv[1] != '-':
	f = open(sys.argv[1], 'r')
else:
	f = sys.stdin
for line in f:
	if line.startswith('#'):
		line = line[1:].strip()
		if not line:
			continue
		if d.has_key(line[0]) and line[1:5].strip().startswith('='):
			dd[line[0]] = line[line.index('=')+1:].strip()
		continue
	ar = line.split('\t')
	for s in ar[1:-1]:
		if s and d.has_key(s[0]):
			d[s[0]].append((s, ar[0]))
f.close()

for c in sys.argv[2]:
	if d[c]:
		d[c].sort()
		if dd.has_key(c):
			print '#', dd[c]
		else:
			print '#', c
		for code, uni in d[c]:
			print '%s\t%s' % (code, uni)
