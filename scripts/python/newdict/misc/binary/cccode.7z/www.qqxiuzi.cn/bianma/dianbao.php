<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
<title>电报码在线翻译（国际摩尔斯电码及中文电码） - 千千秀字</title>
<meta name="keywords" content="电报码,摩尔斯电码,中文电码">
<meta name="description" content="本页面实现电报码和字符间的相互转译，包括国际摩尔斯电码和标准中文电码。中文电码还可选择显示其数字代码，或者将数字代码转译为中文字符。页内有摩尔斯电码表，以及独立页显示的中文电码表。">
<link href="/css/style.css" rel="stylesheet" type="text/css">
<style>
textarea {
	width: 100%;
	height: 150px;
	box-sizing: border-box;
	border: 1px #ccc solid;
	padding: 1%;
	line-height: 140%;
}
textarea:hover {
	border-color:#999;
}
textarea:focus {
	border-color:#59f;
}
@media screen and (max-height:640px) {
textarea {
	height: 100px;
}
}
#show{border:1px #ccc solid;box-sizing:border-box;min-height:150px;padding:1%;font-family: "Courier New", Courier, monospace;}
table{font-family: "Courier New", Courier, monospace;border-collapse:collapse;}
label{display:none;}
</style>
<script>
function ShowData(str1,str2,str3,str4)
{
	var len = str1.replace(/[\r\n]/g,"").length;
	if (len==0)
	{
		if (str2==0)
		document.getElementById("show").innerHTML="请在上面输入文字！";
		else
		document.getElementById("show").innerHTML="请在上面输入电码！";
		return;
	}
	else if (len>2000 && str2==0)
	{
		document.getElementById("show").innerHTML="字数控制在2000以内！当前"+len+"字。";
		return;
	}
	else if (len>10000)
	{
		document.getElementById("show").innerHTML="数据量太大！当前"+len+"，限制为10000。";
		return;
	}
	document.getElementsByClassName('load-container').item(0).style.display='block';
	[].forEach.call(document.querySelectorAll('input[type="button"]'),function(b){b.disabled=true});
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			setTimeout(function(){
				document.getElementById("show").innerHTML=xmlhttp.responseText;
				document.getElementsByClassName('load-container').item(0).style.display='none';
				[].forEach.call(document.querySelectorAll('input[type="button"]'),function(b){b.disabled=false});
			},500);
		}
	}
	xmlhttp.open("POST","dianbao-show.php",true);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.send('text='+encodeURIComponent(str1)+'&ende='+str2+'&l='+str3+'&n='+str4+'&token=065a0f9525727410a52ab3100a02421e');
}
function check(e){
	var tag=document.getElementsByTagName('label').item(0);
	if(e.value=='cn') tag.style.display='inline-block';
	else tag.style.display='none';
}
function ValueGroup(name){
	var obj;
	obj=document.getElementsByName(name);
	if(obj!=null){
		var i;
		for(i=0;i<obj.length;i++){
			if(obj[i].checked){
				return obj[i].value;
			}
		}
	}
	return null;
}
</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script src="/js/head.js"></script>
</head>
<body> 
<div class="load-container">
  <div class="loader"></div>
</div>
<div class="top"><div class="home"><a href="https://www.qqxiuzi.cn"><b><font color="#F8673D">千</font><font color="#E79C01">千</font><font color="#0EBB00">秀</font><font color="#669FFF">字</font></b></a></div><div class="nav"><a href="https://www.qqxiuzi.cn/daohang.htm">网站导航</a></div><div style="clear:both;"></div></div>
<div class="main">
  <div class="title"><h1>电报码在线翻译</h1></div>
  <div class="ad">
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2440711871479504"
     data-ad-slot="8604148262"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div> 
  <textarea class="textarea" id="text"></textarea>
  <div style="margin:10px 0;">
    <input onclick="ShowData(document.getElementById('text').value,0,document.getElementById('l').value,ValueGroup('n'));" type="button" value="编码" name="encode">
    <input onclick="ShowData(document.getElementById('text').value,1,document.getElementById('l').value,ValueGroup('n'));" type="button" value="解码" name="decode">
    <select id="l" onChange="check(this)">
    <optgroup label="语言">
      <option value="en">英文电报</option>
      <option value="cn">中文电报</option>
    </optgroup>
    </select>
    <label><input name="n" type="checkbox" value="1">数字代码</label>
  </div>
  <div id="show"></div>
  <p>电报出现于19世纪，是人类最早用电信号传送信息的方式，在19世纪和20世纪也是主要的通信方式之一。进入21世纪后，电报这种通信方式基本不再使用。</p>
  <p>电报的工作原理：发报方将文字转换成特定的编码，然后以电信号把这些编码发送出去；收报方抄收这些编码，然后翻译成文字。双方都有一个相同的代码本，上面记载了文字和编码的对应关系。显然，使用私有的代码本，可避免无关收报方破译电报文本。</p>
  <p>电报通常使用国际摩尔斯电码进行收发报。摩尔斯电码使用点（·）和划（-）两种符号的特定组合表示不同的字符，在用声音表示时，其中点（·）为短信号，一个时间单位，读作滴，划（-）为长信号，三个时间单位，读作嗒；两个信号间隔一个时间单位，字符间隔三个时间单位，单词间隔七个时间单位。</p>
  <p>摩尔斯电码编码表：</p>
  <div style="overflow:auto">
  <table width="750" border="1" cellpadding="2" cellspacing="0" bordercolor="#999999">
  <caption>
    国际摩尔斯电码（字母）
  </caption>
    <tr>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
    </tr>
    <tr>
      <th>A</th>
      <td>·-</td>
      <th>B</th>
      <td>-···</td>
      <th>C</th>
      <td>-·-·</td>
      <th>D</th>
      <td>-··</td>
      <th>E</th>
      <td>·</td>
      <th>F</th>
      <td>··-·</td>
      <th>G</th>
      <td>--·</td>
    </tr>
    <tr>
      <th>H</th>
      <td>····</td>
      <th>I</th>
      <td>··</td>
      <th>J</th>
      <td>·---</td>
      <th>K</th>
      <td>-·-</td>
      <th>L</th>
      <td>·-··</td>
      <th>M</th>
      <td>--</td>
      <th>N</th>
      <td>-·</td>
    </tr>
    <tr>
      <th>O</th>
      <td>---</td>
      <th>P</th>
      <td>·--·</td>
      <th>Q</th>
      <td>--·-</td>
      <th>R</th>
      <td>·-·</td>
      <th>S</th>
      <td>···</td>
      <th>T</th>
      <td>-</td>
      <th>U</th>
      <td>··-</td>
    </tr>
    <tr>
      <th>V</th>
      <td>···-</td>
      <th>W</th>
      <td>·--</td>
      <th>X</th>
      <td>-··-</td>
      <th>Y</th>
      <td>-·--</td>
      <th>Z</th>
      <td>--··</td>
      <th></th>
      <td></td>
      <th></th>
      <td></td>
    </tr>
</table>
</div>
<br>
<div style="overflow:auto">
<table width="650" border="1" cellpadding="2" cellspacing="0" bordercolor="#999999">
  <caption>
    国际摩尔斯电码（数字）
  </caption>
    <tr>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
    </tr>
    <tr>
      <th>1</th>
      <td>·----</td>
      <th>2</th>
      <td>··---</td>
      <th>3</th>
      <td>···--</td>
      <th>4</th>
      <td>····-</td>
      <th>5</th>
      <td>·····</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-····</td>
      <th>7</th>
      <td>--···</td>
      <th>8</th>
      <td>---··</td>
      <th>9</th>
      <td>----·</td>
      <th>0</th>
      <td>-----</td>
    </tr>
</table>
</div>
<br>
<div style="overflow:auto">
<table width="750" border="1" cellpadding="2" cellspacing="0" bordercolor="#999999">
   <caption>
    国际摩尔斯电码（标点）
  </caption>
   <tr>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
      <th>字符</th>
      <th>代码</th>
    </tr>
    <tr>
      <th>.</th>
      <td>·-·-·-</td>
      <th>:</th>
      <td>---···</td>
      <th>,</th>
      <td>--··--</td>
      <th>;</th>
      <td>-·-·-·</td>
      <th>?</th>
      <td>··--··</td>
      <th>=</th>
      <td>-···-</td>
    </tr>
    <tr>
      <th>'</th>
      <td>·----·</td>
      <th>/</th>
      <td>-··-·</td>
      <th>!</th>
      <td>-·-·--</td>
      <th>-</th>
      <td>-····-</td>
      <th>_</th>
      <td>··--·-</td>
      <th>"</th>
      <td>·-··-·</td>
    </tr>
    <tr>
      <th>(</th>
      <td>-·--·</td>
      <th>)</th>
      <td>-·--·-</td>
      <th>$</th>
      <td>···-··-</td>
      <th>&amp;</th>
      <td>·-···</td>
      <th>@</th>
      <td>·--·-·</td>
      <th>+</th>
      <td>·-·-·</td>
    </tr>
</table>
</div>
  <p>可见，摩尔斯电码只能用来传送字符数量少的语言，面对数量庞大的中文，则需要一次中间编码进行转换，这就是中文电码。通常是以1983年邮电部编写的<a href="dianbao.html" style="color:blue">《标准电码本（修订本）》</a>为规范。中文电码表采用四位阿拉伯数字表示一个中文字符（汉字、字母和符号），从0001到9999顺序排列。汉字先按部首，后按笔画排列；字母和符号放到电码表的最后。发送中文电报时，先按照中文电码本将中文翻译为数字串，再以摩尔斯电码发送这组数字串。收报方先将电码翻译为数字串，再转译为中文即完成。</p>
  <div class="ad2">
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2440711871479504"
     data-ad-slot="8604148262"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div> 
</div>
<div class="foot">QQXIUZI.CN　<a href="https://www.qqxiuzi.cn">千千秀字</a></div>
</body>
</html>
