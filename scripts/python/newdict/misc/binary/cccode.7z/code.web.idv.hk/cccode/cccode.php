<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>中文編碼網頁 → 中文商用電碼</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../js/clock.js"></script>
<script type="text/javascript" src="../js/offsite.js"></script>
<script type="text/javascript">
<!--
if (top.location.href != window.location.href) {
	top.location.href = window.location.href;
}
ie4 = document.all;
ns4 = document.layers;
ns6 = document.getElementById && !document.all;
function getCookie(name) {
	var index = document.cookie.indexOf(name + "=");
	if(index == -1) return null;
	index = document.cookie.indexOf("=", index) + 1;
	var endstr = document.cookie.indexOf(";", index);
	if(endstr == -1) endstr = document.cookie.length;
	return unescape(document.cookie.substring(index, endstr));
}
function chgfontsize(multiplier) {
	if (document.getElementById('bodyContent').style.fontSize == "" || multiplier == "O") {
		document.getElementById('bodyContent').style.fontSize = "1em";
	}
	newsize = parseFloat(document.getElementById('bodyContent').style.fontSize) + (multiplier * 0.2);
	if(newsize < 0.3) { newsize = 0.3;}
	if(newsize > 3) { newsize = 3;}
	if(multiplier != "O") {
		document.cookie = "fontsize=" + newsize + "; path=/";
	}
	else {
		document.cookie = "fontsize=" + newsize + "; path=/; expires=Sat, 01 Jan 2000 00:00:00 UTC";
	}
	document.getElementById('bodyContent').style.fontSize = newsize + "em";
}
servertime = 1000 * 1640228193;
now = new Date();
difference = now.getTime() - servertime;
var message="歡迎光臨中文編碼網頁 ";
//-->
</script>
<link href="data:image/x-icon;base64,AAABAAEAEBACAAAAAACwAAAAFgAAACgAAAAQAAAAIAAAAAEAAQAAAAAAQAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAAKb/AAAAAAAAAAAAZsIAAGbGAABmzAAAZtgAAGbQAAB+4AAAftAAAGDYAABgzAAAYMQAAGDAAADhwAAAAAAAAAAAAAD//wAA//8AAJk9AACZOQAAmTMAAJknAACZLwAAgR8AAIEvAACfJwAAnzMAAJ87AACfPwAAHj8AAP//AAD//wAA" rel="icon" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="../include/kode-r.css" title="Red" />
<link rel="alternate stylesheet" type="text/css" href="../include/kode-b.css" title="Blue" />
<link rel="alternate stylesheet" type="text/css" href="../include/kode-y.css" title="Yellow" />
<link rel="stylesheet" type="text/css" href="../include/kprint.css" media="print" />
<style type="text/css">
<!--
td, th {text-align:center; border:solid 1px;}
table {border:solid 1px; border-collapse:collapse; margin:auto; width:85%; padding:0.3em 0.3em;}
h2 {text-align:center;}
.framebox {border-style:solid; border-width:0px 1px 1px 1px; border-collapse:collapse; margin:auto; width:85%; padding:0.3em 0.3em;}
.frameboxtop {border:solid 1px; border-collapse:collapse; margin:auto; width:85%; padding:0.3em 0.3em;}
-->
</style>
</head>
<body id="bodyContent">
<div id="Content">
<div class="divcenter">
<span class="kode03"><script type="text/javascript" src="../js/neon.js"></script></span>
<noscript>
<div class="kode03">歡迎光臨中文編碼網頁</div>
</noscript>
</div><h1 class="chinese divcenter">標準電碼本(中文商用電碼)</h1>
<p></p>
<p class ="divcenter"><img src="http://guest.web.idv.hk/image/conbart.png" alt="Under Construction" /></p>
<p class="divcenter">中文商用電碼（Chinese Commercial Code），又稱中文電報碼（Chinese Telegraph Code），<br />產生於1871年至1881年間。現時分開中國大陸、香港和台灣版本。</p>

<h2 class="divcenter"><a href="mocode.php">澳門政府1985年版本</a></h2>
<p/>
<h2 class="divcenter">香港商務印書館1972年版本</h2>
<table>
<tr><th>部首劃數</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>一劃</td><td>一丨丶丿乙亅</td><td><a href="cccode01.php">00XX</a></td></tr>
<tr><td rowspan="5">二劃</td><td>二亠人(亻)</td><td><a href="cccode01.php">00XX</a></td></tr>
<tr><td>儿入八冂冖冫</td><td><a href="cccode01.php#s03">03XX</a></td></tr>
<tr><td>几凵刀(刂)</td><td><a href="cccode01.php#s04">04XX</a></td></tr>
<tr><td>力勹匕匚匸十卜卩(已)</td><td><a href="cccode01.php#s05">05XX</a></td></tr>
<tr><td>厂厶又</td><td><a href="cccode01.php#s06">06XX</a></td></tr>
<tr><td rowspan="8">三劃</td><td>口</td><td><a href="cccode01.php#s06">06XX</a></td></tr>
<tr><td>囗土</td><td><a href="cccode01.php#s09">09XX</a></td></tr>
<tr><td>士夂夊夕大女</td><td><a href="cccode01.php#s11">11XX</a></td></tr>
<tr><td>子宀</td><td><a href="cccode01.php#s13">13XX</a></td></tr>
<tr><td>寸小尢(尣)尸屮山</td><td><a href="cccode01.php#s14">14XX</a></td></tr>
<tr><td>巛工己巾</td><td><a href="cccode01.php#s15">15XX</a></td></tr>
<tr><td>干幺广廴廾</td><td><a href="cccode01.php#s16">16XX</a></td></tr>
<tr><td>弋弓彐(彑)彡彳</td><td><a href="cccode01.php#s17">17XX</a></td></tr>
<tr><td rowspan="10">四劃</td><td>心(忄)</td><td><a href="cccode01.php#s18">18XX</a></td></tr>
<tr><td>戈戶手(扌)</td><td><a href="cccode02.php">20XX</a></td></tr>
<tr><td>支攴(攵)</td><td><a href="cccode02.php#s23">23XX</a></td></tr>
<tr><td>文斗斤方无日</td><td><a href="cccode02.php#s24">24XX</a></td></tr>
<tr><td>曰月</td><td><a href="cccode02.php#s25">25XX</a></td></tr>
<tr><td>木</td><td><a href="cccode02.php#s26">26XX</a></td></tr>
<tr><td>欠止歹</td><td><a href="cccode02.php#s29">29XX</a></td></tr>
<tr><td>殳毋(母)比毛氏气水(氵氺)</td><td><a href="cccode02.php#s30">30XX</a></td></tr>
<tr><td>火(灬)</td><td><a href="cccode02.php#s34">34XX</a></td></tr>
<tr><td>爪父爻爿片牙牛(牜)犬(犭)</td><td><a href="cccode02.php#s36">36XX</a></td></tr>
<tr><td rowspan="8">五劃</td><td>玄玉(王)</td><td><a href="cccode02.php#s37">37XX</a></td></tr>
<tr><td>瓜瓦甘生用田疋(?)疒</td><td><a href="cccode02.php#s39">39XX</a></td></tr>
<tr><td>癶</td><td><a href="cccode03.php">40XX</a></td></tr>
<tr><td>白皮皿目(罒)</td><td><a href="cccode03.php#s41">41XX</a></td></tr>
<tr><td>矛矢石</td><td><a href="cccode03.php#s42">42XX</a></td></tr>
<tr><td>示(礻)</td><td><a href="cccode03.php#s43">43XX</a></td></tr>
<tr><td>禸禾穴</td><td><a href="cccode03.php#s44">44XX</a></td></tr>
<tr><td>立</td><td><a href="cccode03.php#s45">45XX</a></td></tr>
<tr><td rowspan="11">六劃</td><td>竹</td><td><a href="cccode03.php#s45">45XX</a></td></tr>
<tr><td>米糸</td><td><a href="cccode03.php#s47">47XX</a></td></tr>
<tr><td>缶网(&#156266;)</td><td><a href="cccode03.php#s49">49XX</a></td></tr>
<tr><td>羊羽老而耒</td><td><a href="cccode03.php#s50">50XX</a></td></tr>
<tr><td>耳聿肉(?)</td><td><a href="cccode03.php#s51">51XX</a></td></tr>
<tr><td>臣自至臼舌舛舟</td><td><a href="cccode03.php#s52">52XX</a></td></tr>
<tr><td>艮色艸(艹)</td><td><a href="cccode03.php#s53">53XX</a></td></tr>
<tr><td>虍虫</td><td><a href="cccode03.php#s57">57XX</a></td></tr>
<tr><td>血行</td><td><a href="cccode03.php#s58">58XX</a></td></tr>
<tr><td>衣(衤)</td><td><a href="cccode03.php#s59">59XX</a></td></tr>
<tr><td>襾</td><td><a href="cccode04.php">60XX</a></td></tr>
<tr><td rowspan="6">七劃</td><td>見角言</td><td><a href="cccode04.php">60XX</a></td></tr>
<tr><td>谷豆豕豸貝</td><td><a href="cccode04.php#s62">62XX</a></td></tr>
<tr><td>赤走足</td><td><a href="cccode04.php#s63">63XX</a></td></tr>
<tr><td>身車辛辰辵(辶)</td><td><a href="cccode04.php#s65">65XX</a></td></tr>
<tr><td>邑(?)酉</td><td><a href="cccode04.php#s67">67XX</a></td></tr>
<tr><td>釆里</td><td><a href="cccode04.php#s68">68XX</a></td></tr>
<tr><td rowspan="4">八劃</td><td>金</td><td><a href="cccode04.php#s68">68XX</a></td></tr>
<tr><td>長門阜(阝)</td><td><a href="cccode04.php#s70">70XX</a></td></tr>
<tr><td>隶隹雨</td><td><a href="cccode04.php#s71">71XX</a></td></tr>
<tr><td>青非</td><td><a href="cccode04.php#s72">72XX</a></td></tr>
<tr><td rowspan="3">九劃</td><td>面革韋韭音</td><td><a href="cccode04.php#s72">72XX</a></td></tr>
<tr><td>頁風飛食</td><td><a href="cccode04.php#s73">73XX</a></td></tr>
<tr><td>首香</td><td><a href="cccode04.php#s74">74XX</a></td></tr>
<tr><td rowspan="3">十劃</td><td>馬</td><td><a href="cccode04.php#s74">74XX</a></td></tr>
<tr><td>骨高髟鬥鬯</td><td><a href="cccode04.php#s75">75XX</a></td></tr>
<tr><td>鬲鬼</td><td><a href="cccode04.php#s76">76XX</a></td></tr>
<tr><td rowspan="3">十一劃</td><td>魚鳥</td><td><a href="cccode04.php#s76">76XX</a></td></tr>
<tr><td>鹵鹿麥</td><td><a href="cccode04.php#s77">77XX</a></td></tr>
<tr><td>麻</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十二劃</td><td>黃黍黑黹</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十三劃</td><td>黽鼎鼓鼠</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十四劃</td><td>鼻齊</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十五劃</td><td>齒</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十六劃</td><td>龍龜</td><td><a href="cccode04.php#s78">78XX</a></td></tr>
<tr><td>十七劃</td><td>龠</td><td><a href="cccode04.php#s79">79XX</a></td></tr>
</table>
<p></p>
<h2>電碼補遺</h2>
<table>
<tr><th>部首劃數</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>一劃</td><td>一丨丿乙</td><td><a href="cccode05.php">80XX</a></td></tr>
<tr><td rowspan="2">二劃</td><td>二人儿冫冖</td><td><a href="cccode05.php">80XX</a></td></tr>
<tr><td>刀力勹</td><td><a href="cccode05.php#s81">81XX</a></td></tr>
<tr><td rowspan="3">三劃</td><td>尢又口囗土</td><td><a href="cccode05.php#s81">81XX</a></td></tr>
<tr><td>大女</td><td><a href="cccode05.php#s82">82XX</a></td></tr>
<tr><td>子宀寸小尸山巾广廾弋彳</td><td><a href="cccode05.php#s83">83XX</a></td></tr>
<tr><td rowspan="5">四劃</td><td>心</td><td><a href="cccode05.php#s83">83XX</a></td></tr>
<tr><td>戈戶手攴斗方</td><td><a href="cccode05.php#s84">84XX</a></td></tr>
<tr><td>日月木</td><td><a href="cccode05.php#s85">85XX</a></td></tr>
<tr><td>欠歹殳比毛气水</td><td><a href="cccode05.php#s86">86XX</a></td></tr>
<tr><td>火片牛犬</td><td><a href="cccode05.php#s87">87XX</a></td></tr>
<tr><td rowspan="2">五劃</td><td>玉瓦生田疒白皿目</td><td><a href="cccode05.php#s88">88XX</a></td></tr>
<tr><td>矛矢石示禾穴</td><td><a href="cccode05.php#s89">89XX</a></td></tr>
<tr><td rowspan="3">六劃</td><td>立竹米糸缶网羊羽</td><td><a href="cccode05.php#s90">90XX</a></td></tr>
<tr><td>而耒耳肉舟艸</td><td><a href="cccode05.php#s91">91XX</a></td></tr>
<tr><td>虍虫衣</td><td><a href="cccode05.php#s92">92XX</a></td></tr>
<tr><td rowspan="3">七劃</td><td>角言</td><td><a href="cccode05.php#s92">92XX</a></td></tr>
<tr><td>谷豕豸貝走足車辵邑</td><td><a href="cccode05.php#s93">93XX</a></td></tr>
<tr><td>酉</td><td><a href="cccode05.php#s94">94XX</a></td></tr>
<tr><td rowspan="2">八劃</td><td>金</td><td><a href="cccode05.php#s94">94XX</a></td></tr>
<tr><td>門阜隹雨青</td><td><a href="cccode05.php#s95">95XX</a></td></tr>
<tr><td>九劃</td><td>革韋音頁風飛食</td><td><a href="cccode05.php#s95">95XX</a></td></tr>
<tr><td>十劃</td><td>香馬骨髟鬼</td><td><a href="cccode05.php#s96">96XX</a></td></tr>
<tr><td>十一劃</td><td>魚鳥麥</td><td><a href="cccode05.php#s96">96XX</a></td></tr>
<tr><td>十二劃</td><td>黑</td><td><a href="cccode05.php#s96">96XX</a></td></tr>
<tr><td>十三劃</td><td>鼠</td><td><a href="cccode05.php#s96">96XX</a></td></tr>
<tr><td>十七劃</td><td>龠</td><td><a href="cccode05.php#s96">96XX</a></td></tr>
<tr><td>特別符號</td><td>&nbsp;</td><td><a href="cccode05.php#s97">97XX</a></td></tr>
</table>
<p></p>
<div class="frameboxtop">部分資料來自香港商務印書館《新編標準電碼本》1972年版，1988年重印 (<a href="http://publish.commercialpress.com.hk/b5_book_detail.php?id=5464">ISBN 962-07-2005-9</a>)<br />
<!--old-->綠色字為舊版本電碼<br />
<!--s3-->橙色字為新版本電碼，該字曾被編到另一個電碼之中<br />
<!--s1-->灰色字為「補充字碼表」(p.114-121)<br />
<!--s2-->棕色字為「新添字碼參考表」(p.125-127)<br />
<!--china1-->藍色字為內地簡化漢字電碼<br />
<!--china2-->紅色字為1981年內地電碼修訂之新用字，不通用於港澳台。</div>
<!-- Number of accesses by previous Netfirms counter between 2003-09-05 to 2004-01-27 : 545 -->
<p class="divcenter"><a href="../index.php">返回主網頁</a></p>
<div class="divcenter">
<span style="font-size:83%;" class="cScreen">
<a href="javascript:chgfontsize(+1);">[放大字體]</a>
<a href="javascript:chgfontsize(-1);">[縮小字體]</a>
<a href="javascript:chgfontsize('O');">[原來大小]</a>
<br /></span>
<script type="text/javascript" src="../js/clockto.js"></script><br />
<span style="font-size:83%;font-style:italic;"><img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIGJhc2VQcm9maWxlPSJmdWxsIiB2aWV3Qm94PSIwIDAgMTAwIDIwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIyMDAiPgo8ZyBmaWxsPSJibGFjayI+CjxwYXRoIGQ9Ik0gMTUuNCAxMTYuMiBMIDE3LjcgMTIzLjUgTCAyMC43IDEzMC4wIEwgMjQuNSAxMzUuNiBMIDI4LjcgMTQwLjQgTCAzMy41IDE0NC4yIEwgMzguNiAxNDYuOSBMIDQ0LjEgMTQ4LjYgTCA0OS45NSAxNDkuMTk0OTE1Mjk0NjQ3MjIgTCA1NS44IDE0OC42IEwgNjEuMyAxNDYuOSBMIDY2LjQgMTQ0LjIgTCA3MS4yIDE0MC40IEwgNzUuNCAxMzUuNiBMIDc5LjIgMTMwLjAgTCA4Mi4yIDEyMy41IEwgODQuNSAxMTYuMiBMIDg2LjAgMTA4LjQgTCA4Ni41IDEwMC4wIEwgODYuMCA5MS41IEwgODQuNSA4My43IEwgODIuMiA3Ni40IEwgNzkuMiA2OS45IEwgNzUuNCA2NC4zIEwgNzEuMiA1OS41IEwgNjYuNCA1NS43IEwgNjEuMyA1My4wIEwgNTUuOCA1MS4zIEwgNTAuMCA1MC43IEwgNDQuMSA1MS4zIEwgMzguNiA1My4wIEwgMzMuNSA1NS43IEwgMjguNyA1OS41IEwgMjQuNSA2NC4zIEwgMjAuNyA2OS45IEwgMTcuNyA3Ni40IEwgMTUuNCA4My43IEwgMTMuOSA5MS41IEwgMTMuNSAxMDAuMCBMIDEzLjkgMTA4LjQgWiBNIDM1LjkgNzcuNiBMIDM1LjEgNzguNSBMIDM0LjIgNzkuMyBMIDMzLjQgODAuMSBMIDMyLjUgODAuOSBMIDMxLjUgODEuNyBMIDMwLjYgODIuNSBMIDI5LjYgODMuMyBMIDI5LjIgODQuMyBMIDI3LjUgODMuNiBMIDI3LjggODIuNiBMIDI3LjUgODEuNCBMIDI2LjkgNzcuOCBMIDI2LjggNzYuNiBMIDI2LjYgNzUuNCBMIDI2LjUwMDA3NjAwNzg0MzAxNyA3NC4zMDA4MzU4OTU1MzgzMyBMIDI2LjEgNzQuNCBMIDI2LjQgNzMuMiBMIDI2LjQwNTcxNDMyMTEzNjQ3NSA3My4xNjg1NzE0NzIxNjc5NyBMIDI2LjMgNzEuOSBMIDI2LjYyMjYyMDc3MzMxNTQzIDcyLjAxNzA1NzEzMjcyMDk1IEwgMjYuOSA3MS4wIEwgMjcuMSA2OS45IEwgMjcuNCA2OC43IEwgMjcuOCA2Ny42IEwgMjguMSA2Ni41IEwgMjguNSA2NS4zIEwgMjguOSA2NC4yIEwgMjguNyA2My4yIEwgMzAuNCA2Mi43IEwgMzAuNyA2My43IEwgMzIuNzcwMjcwMjUyMjI3NzggNjUuNzcwMjcwMjUyMjI3NzkgTCAzNS4wIDY0LjcgTCAzNy42IDYzLjkgTCA0MC4zIDYzLjUgTCA0Mi45IDYzLjQgTCA0NS41IDYzLjcgTCA0OC4xIDY0LjIgTCA0OC42MzQxODE3ODU1ODM0OSA2NC40MDU0NTQ1NDAyNTI2OSBMIDUxLjIgNjQuMSBMIDU1LjYgNjQuNiBMIDU5LjkgNjYuMiBMIDY0LjAgNjguOCBMIDY3LjggNzIuNCBMIDcxLjAgNzYuOSBMIDczLjcgODIuMiBMIDc1LjcgODguNCBMIDc3LjAgOTUuNCBMIDc3LjQ0ODEzNjgwNjQ4ODA0IDEwMi4zMDEzMDc0ODc0ODc3OSBMIDc3LjUgMTAyLjMgTCA3Ny40Njc2OTQ1Njg2MzQwMyAxMDIuNjAyNDk2MzM3ODkwNjMgTCA3Ny41IDEwMy4xIEwgNzcuNDE0NzkyNTM3Njg5MjEgMTAzLjA5Nzg1MTk0Mzk2OTczIEwgNzYuNCAxMTIuNiBMIDczLjQgMTIxLjQgTCA2OC43IDEyOC41IEwgNjIuNyAxMzMuNyBMIDU1LjcgMTM2LjYgTCA0OC40IDEzNy4xIEwgNDEuMiAxMzUuMSBMIDM0LjYgMTMwLjcgTCAyOS4wIDEyMy45IEwgMjUuMzUxMzUxMzU2NTA2MzUgMTE2LjUyMTYyMTYwODczNDE0IEwgMjQuNSAxMTQuOSBMIDI0LjUzOTE5MDU3ODQ2MDY5NCAxMTQuODc5MjUyMDUyMzA3MTIgTCAyNC41IDExNC44IEwgMjUuMzUgMTE0LjQ1IEwgMjYuMiAxMTQuMCBMIDMxLjUgMTIwLjYgTCAzNy4xIDEyNC44IEwgNDIuNiAxMjYuOSBMIDQ3LjcgMTI3LjQgTCA1Mi40IDEyNi40IEwgNTYuNiAxMjQuMCBMIDYwLjEgMTIwLjUgTCA2Mi44IDExNS43IEwgNjQuNSAxMDkuNyBMIDY1LjAgMTAyLjUgTCA2NS4wMDQ2MTU0MDIyMjE2NyAxMDIuNSBMIDY1LjEgOTYuMyBMIDY0LjcgOTAuNCBMIDYzLjggODUuNCBMIDYyLjUgODEuMCBMIDYwLjggNzcuMiBMIDU4LjcgNzQuMCBMIDU2LjMgNzEuNCBMIDUzLjYgNjkuMyBMIDUwLjUgNjcuNSBMIDUwLjI3ODQ4MTAwNjYyMjMxNCA2Ny40MzAzNzk3NzIxODYyOCBMIDQ4LjAgNjguMCBMIDQ1LjkgNjguNiBMIDQ0LjAgNjkuNCBMIDQyLjQgNzAuNCBMIDQxLjAgNzEuNSBMIDM5LjkgNzIuNiBMIDM4LjkgNzMuOSBMIDM4LjEgNzUuMyBMIDM3LjMgNzYuOCBMIDM1Ljk4ODUyNDYyNzY4NTU1IDc3LjUyMTMxMTQ3Mzg0NjQ0IFogTSA5Ni4yIDExOS4xIEwgOTMuNCAxMjcuOCBMIDg5LjYgMTM1LjggTCA4NS4wIDE0Mi45IEwgNzkuNCAxNDkuMSBMIDczLjAgMTU0LjIgTCA2NS45IDE1OC4wIEwgNTguMiAxNjAuNCBMIDUwLjAgMTYxLjIgTCA0OS45NSAxNTUuMiBMIDQ5LjkgMTYxLjIgTCA0MS43IDE2MC40IEwgMzQuMCAxNTguMCBMIDI2LjkgMTU0LjIgTCAyMC41IDE0OS4xIEwgMTQuOSAxNDIuOSBMIDEwLjMgMTM1LjggTCA2LjUgMTI3LjggTCAzLjcgMTE5LjEgTCAyLjAgMTA5LjggTCAxLjUgMTAwLjAgTCAyLjAgOTAuMSBMIDMuNyA4MC44IEwgNi41IDcyLjEgTCAxMC4zIDY0LjEgTCAxNC45IDU3LjAgTCAyMC41IDUwLjggTCAyNi45IDQ1LjcgTCAzNC4wIDQxLjkgTCA0MS43IDM5LjUgTCA1MC4wIDM4LjcgTCA1OC4yIDM5LjUgTCA2NS45IDQxLjkgTCA3My4wIDQ1LjcgTCA3OS40IDUwLjggTCA4NS4wIDU3LjAgTCA4OS42IDY0LjEgTCA5My40IDcyLjEgTCA5Ni4yIDgwLjggTCA5Ny45IDkwLjEgTCA5OC41IDEwMC4wIEwgOTcuOSAxMDkuOCBaICIgLz4KPC9nPgo8L3N2Zz4=" alt="Copyleft &#127279;" style="height:1.2em;vertical-align:-15%;"/> 2004-2019 <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIGJhc2VQcm9maWxlPSJmdWxsIiAgd2lkdGg9IjE2NSIgaGVpZ2h0PSIzMCI+PHRleHQgeD0iMCIgeT0iMjAiIGZpbGw9ImJsYWNrIiBmb250LXN0eWxlPSJpdGFsaWMiPuKAimtsbmVhc3RAeWFob28uY29tLmhrPC90ZXh0Pjwvc3ZnPg==" alt="My Email" style="height:1.8em;vertical-align:-50%;"/>
本頁更新日期：8 September 2019</span>
<!--<p><span style="font-size:83%;padding-left:2em;vertical-align:middle;">&#26412;&#32178;&#26377;1279115&#20154;&#28687;&#35261;&#12290;&#26412;&#38913;&#21443;&#35264;&#20154;&#25976;&#65306;149595</span></p>-->
</div>
</div>
<div id="Menu">
<p style="text-indent:0.8em;"><a href="javascript:chgfontsize(+1);">[放大字體]</a></p>
<p style="margin-top:-0.5em;text-indent:0.8em;"><a href="javascript:chgfontsize(-1);">[縮小字體]</a></p>
<p style="margin-top:-0.5em;text-indent:0.8em;"><a href="javascript:chgfontsize('O');">[原來大小]</a></p>
<div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 125x125 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:125px;height:125px"
     data-ad-client="ca-pub-0927799012174491"
     data-ad-slot="0153402065"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div><div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 0822248218 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:120px;height:600px"
     data-ad-client="ca-pub-0927799012174491"
     data-ad-slot="0822248218"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<p><a href="http://www.dnsexit.com/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAMAAAA3Z0MzAAADAFBMVEUzM2b/5Mj6dRKhoaH/sGH8ji5MTHmzs8b/0qX8fhH//Pn7exllZYz/w4f/okTm5uyMjKnNzdn/ixj/uXP/3rxzc5Y/P2//9/D+xpH+pFL/nTqlpbz7fR7/797/kSOamrPZ2eL/hw/9rmpZWYN/f5/9voj/qlX9lz/////9xpz/mTO/v8/z8/by8vX/1qz+t3f/iRL/jx7/8eb+zaH/6dj8nlb8hCH/lCj6dxb/4cP/pUr9plv/tm3/rVr8hyn/smT/ly6AgKDZ2eP/9Oj8hBz9m0RAQHD/+vX/5sz/zJn/7Nj/v37/ypb/2bT90K76exsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNcF5PAAAACXBIWXMAAA7EAAAOxAGVKw4bAAACNElEQVR42sXVDXOaQBAG4NUoKIVY1JSKQXKm2m3URpq0KaQqjSk2X+3//zfdPWHEKn7MOJN39BBmfLi7XQY4OnzgCA+d1zP9kSe2xRv5+5ilsFArNOywNdzMlnY3fbtWmzTsi1Z121z9nc3RDyKPdyDFaLtpmhU+iNqke3zRaAQcEQY2/dsOQkE/gnnCBF0ygfNhgOiCS6c6IJ5FdOktm0zexBUQNlqe8Cy0BfoivrmRbYLOZjSYmwoo5wAmMUxWfTQ4XImS/LJpGCV0DCNYbxLXi0hwgSdK5hmc8B1+kknkcOhj0jQWGjxXNoUI5JhpYpOWSqYiTZPNiquSyeTCFEa82sSs5j4/dW+G602TRhcUUNnsA5w3B3ILq4s+kZNy0BFp8xFxOnXqT9kmqXI/XUhqFPeeT3meL97xUqZ4kIT2sM6sSNPUQWUTewrIzU3MrLWLrkVXppMNazfpIE3EuxPe3P/MEHGCGKbMloMaolVvrTF7VGUyaeURoKr3ZI8tTNnennjBZ+qll3Td6+jQVLXf9qpJi5amSmumJqC6D9KmTBDEPR+kzEutcKVxBZfNd7pOTd6XJrU70OaC7ioMl2XaHZliu3NLZ7eddpk+5XKRx4/OffGalC+rz5Fyh3NT5enxbCGiJ/5vfmvG+fwfLv2SaXL6XHs5miZXyHWbfPI1v0s+rZibcn36nfNmKaep3FPGj/u9O3LFbxkZJ/mV0/Z9x11dNjbmvTWbzV7/vbm3efj8Ayq6EYOVM/vXAAAAAElFTkSuQmCC" alt="dnsExit.Com" /></a></p>
<!--<p style="margin-top:-0.5em;"><a href="http://www.prchecker.info/" title="PRchecker.info" rel="nofollow"><img src="http://pr-v2.prchecker.info/getpr.v2.php?codex=aHR0cDovL2NvZGUud2ViLmlkdi5oaw==&amp;tag=1" alt="PRchecker.info" /></a></p>-->
<script type="text/javascript">
<!--
if(getCookie('fontsize') !== false) {
	document.getElementById('bodyContent').style.fontSize=getCookie('fontsize') + "em";
}
//-->
</script>
</div>
</body>
</html>
