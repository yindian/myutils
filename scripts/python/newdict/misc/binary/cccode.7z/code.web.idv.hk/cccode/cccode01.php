<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>中文編碼網頁 → 中文商用電碼</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../js/clock.js"></script>
<script type="text/javascript" src="../js/offsite.js"></script>
<script type="text/javascript">
<!--
if (top.location.href != window.location.href) {
	top.location.href = window.location.href;
}
ie4 = document.all;
ns4 = document.layers;
ns6 = document.getElementById && !document.all;
function getCookie(name) {
	var index = document.cookie.indexOf(name + "=");
	if(index == -1) return null;
	index = document.cookie.indexOf("=", index) + 1;
	var endstr = document.cookie.indexOf(";", index);
	if(endstr == -1) endstr = document.cookie.length;
	return unescape(document.cookie.substring(index, endstr));
}
function chgfontsize(multiplier) {
	if (document.getElementById('bodyContent').style.fontSize == "" || multiplier == "O") {
		document.getElementById('bodyContent').style.fontSize = "1em";
	}
	newsize = parseFloat(document.getElementById('bodyContent').style.fontSize) + (multiplier * 0.2);
	if(newsize < 0.3) { newsize = 0.3;}
	if(newsize > 3) { newsize = 3;}
	if(multiplier != "O") {
		document.cookie = "fontsize=" + newsize + "; path=/";
	}
	else {
		document.cookie = "fontsize=" + newsize + "; path=/; expires=Sat, 01 Jan 2000 00:00:00 UTC";
	}
	document.getElementById('bodyContent').style.fontSize = newsize + "em";
}
servertime = 1000 * 1640228215;
now = new Date();
difference = now.getTime() - servertime;
var message="歡迎光臨中文編碼網頁 ";
//-->
</script>
<link href="data:image/x-icon;base64,AAABAAEAEBACAAAAAACwAAAAFgAAACgAAAAQAAAAIAAAAAEAAQAAAAAAQAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAAKb/AAAAAAAAAAAAZsIAAGbGAABmzAAAZtgAAGbQAAB+4AAAftAAAGDYAABgzAAAYMQAAGDAAADhwAAAAAAAAAAAAAD//wAA//8AAJk9AACZOQAAmTMAAJknAACZLwAAgR8AAIEvAACfJwAAnzMAAJ87AACfPwAAHj8AAP//AAD//wAA" rel="icon" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="../include/kode-r.css" title="Red" />
<link rel="alternate stylesheet" type="text/css" href="../include/kode-b.css" title="Blue" />
<link rel="alternate stylesheet" type="text/css" href="../include/kode-y.css" title="Yellow" />
<link rel="stylesheet" type="text/css" href="../include/kprint.css" media="print" />
<style type="text/css">
<!--
pre {white-space:pre;font-size:150%;padding-left:2em;letter-spacing:-0.05em;}
.china1 {color:blue;}
.china2 {color:red;}
.old {color:green;text-decoration:underline;}
.s1 {color:#666;text-decoration:underline;}
.s2 {color:brown;text-decoration:underline;}
.s3 {color:orange;text-decoration:underline;}
.simp {color:#999;display:none;}
@font-face {
	font-family: UserDefine;
	src: url('../glyphsvg/UserDefine.eot');
	src: url('../glyphsvg/UserDefine.eot?#iefix') format('embedded-opentype'),
		url('../glyphsvg/UserDefine.svg') format('svg'),
		url('../glyphsvg/UserDefine.woff') format('woff'),
		url('../glyphsvg/UserDefine.ttf') format('truetype');
	font-weight: normal;
	font-style: normal;
}
.UserDefine {font-family:UserDefine;}
-->
</style>
</head>
<body id="bodyContent">
<div id="Content">
<div class="divcenter">
<span class="kode03"><script type="text/javascript" src="../js/neon.js"></script></span>
<noscript>
<div class="kode03">歡迎光臨中文編碼網頁</div>
</noscript>
</div><h1 class="chinese divcenter">標準電碼本(中文商用電碼)</h1>
<p></p>
<pre>
電碼	單一碼	中文
<a id="s00"></a>
0001	U+4E00:一
0002	U+4E01:丁
0003	U+4E03:七
0004	U+4E08:丈
0005	U+4E09:三
0006	U+4E0A:上
0007	U+4E0B:下
0008	U+4E0D:不
0009	U+4E10:丐
0010	U+4E11:丑
0011	U+4E14:且
0012	U+4E15:丕
0013	U+4E16:世
0014	U+4E19:丙
0015	U+4E1E:丞
0016	U+4E1F:丟
0017	U+4E26:並
0018	<span class="s2">U+4E0F:丏</span>
0019	U+4E28:丨
0020	U+4E2A:个
0021	U+4E2B:丫
0022	U+4E2D:中
0023	U+4E30:丰
0024	U+4E31:丱
0025	U+4E32:串
0026	<span class="s1">U+9312:錒</span>
0027	U+4E36:丶
0028	<span class="s1">U+9384:鎄</span>
0029	U+4E38:丸
0030	U+4E39:丹
0031	U+4E3B:主
0032	<span class="s1">U+7839:砹</span>
0033	U+4E3F:丿
0034	U+4E42:乂
0035	U+4E43:乃
0036	U+4E45:久
0037	U+4E4B:之
0038	U+4E4D:乍
0039	U+4E4E:乎
0040	U+4E4F:乏
0041	U+4E56:乖
0042	U+4E58:乘
0043	<span class="s1">U+6849:桉</span>
0044	U+4E59:乙
0045	U+4E5C:乜
0046	U+4E5D:九
0047	U+4E5E:乞
0048	U+4E5F:也
0049	<span class="old">U+4E69:乩</span>	<span class="s2">U+4E81:亁</span>
0050	U+4E73:乳
0051	U+4E7E:乾
0052	U+4E82:亂	<span class="china1">U+4E71:乱</span>
0053	U+6C39:氹
0054	U+4E85:亅
0055	U+4E86:了
0056	U+4E88:予
0057	U+4E8B:事
0058	<span class="s1">U+82EF:苯</span>
0059	U+4E8C:二
0060	U+4E8E:于
0061	U+4E91:云
0062	U+4E92:互
0063	U+4E94:五
0064	U+4E95:井
0065	U+4E99:亙
0066	U+2F81B:<span style="font-family:UserDefine;">&#x2F81B;</span> (<a href="http://dict.variants.moe.edu.tw/variants/rbt/word_attribute.rbt?quote_code=QTAyMTczLTAwMQ">參考此字</a>)
0067	U+4E9B:些
0068	U+4E9E:亞	<span class="china1">U+4E9A:亚</span>
0069	U+4E9F:亟
0070	<span class="s1">U+5421:吡</span>
0071	U+4EA0:亠
0072	U+4EA1:亡
0073	U+4EA2:亢
0074	U+4EA4:交
0075	U+4EA5:亥
0076	U+4EA6:亦
0077	U+4EA8:亨
0078	U+4EAB:享
0079	U+4EAC:京
0080	U+4EAD:亭
0081	U+4EAE:亮
0082	U+4EB3:亳
0083	U+4EB6:亶
0084	U+4EB9:亹
0085	<span class="s1">U+91AD:醭</span>
0086	U+4EBA:人
0087	U+4EC0:什
0088	U+4EC1:仁
0089	U+4EC3:仃
0090	U+4EC4:仄
0091	U+4EC6:仆
0092	U+4EC7:仇
0093	U+4ECA:今
0094	U+4ECB:介
0095	U+4ECD:仍
0096	<span class="old">U+4EC2:仂</span>	<span class="s3">U+4F63:佣</span>
0097	<span class="old">U+4EC9:仉</span>	<span class="s2">U+4F6C:佬</span>
0098	U+4ED4:仔
0099	U+4ED5:仕
<a id="s01"></a>
0100	U+4ED6:他
0101	U+4ED7:仗
0102	U+4ED8:付
0103	U+4ED9:仙
0104	U+4EDD:仝
0105	U+4EDE:仞
0106	U+4EE1:仡
0107	U+4EDF:仟
0108	U+4EE3:代
0109	U+4EE4:令
0110	U+4EE5:以
0111	U+4EF0:仰
0112	U+4EF2:仲
0113	U+4EF3:仳
0114	U+4EF5:仵
0115	U+4EF6:件
0116	U+4EF7:价
0117	U+4EFB:任
0118	U+4EFD:份
0119	U+4EFF:仿
0120	U+4F01:企
0121	U+4F09:伉
0122	U+4F0A:伊
0123	U+4F0B:伋
0124	U+4F0D:伍
0125	U+4F0E:伎
0126	U+4F0F:伏
0127	U+4F10:伐
0128	U+4F11:休
0129	U+4F19:伙
0130	U+4F2F:伯
0131	U+4F30:估
0132	U+4F60:你
0133	U+4F34:伴
0134	U+4F36:伶
0135	U+4F38:伸
0136	U+4F3A:伺
0137	U+4F3B:伻
0138	U+4F3C:似
0139	<span class="old">U+4F3D:伽</span>	<span class="s3">U+502E:倮</span>
0140	U+4F43:佃
0141	U+4F46:但
0142	U+4F48:佈
0143	U+4F4D:位
0144	U+4F4E:低
0145	U+4F4F:住
0146	U+4F50:佐
0147	U+4F51:佑
0148	U+4F54:佔
0149	U+4F55:何
0150	U+4F57:佗
0151	U+4F59:余
0152	U+4F58:佘
0153	U+4F5A:佚
0154	U+4F5B:佛
0155	U+4F5C:作
0156	U+4F5E:佞
0157	U+4F5F:佟
0158	U+4F7A:佺
0159	<span class="old">U+4F7D:佽</span>	<span class="s3">U+50A2:傢</span>
0160	U+4F69:佩
0161	U+4F6A:佪	<span class="china2">U+4F22:伢</span>
0162	U+4F6F:佯
0163	U+4F73:佳
0164	U+4F75:併
0165	U+4F76:佶
0166	U+4F78:佸	<span class="china2">U+4F5D:佝</span>
0167	U+4F7B:佻
0168	U+4F7E:佾
0169	U+4F7F:使
0170	U+4F83:侃
0171	U+4F86:來	<span class="china1">U+6765:来</span>
0172	U+4F88:侈
0173	U+4F8B:例
0174	U+4F8D:侍
0175	U+4F8F:侏
0176	U+4F91:侑
0177	U+4F94:侔
0178	U+4F96:侖
0179	U+4F97:侗
0180	U+4F9B:供
0181	U+4F9D:依
0182	U+4FB7:侷
0183	<span class="old">U+4FD4:俔</span>	<span class="s3">U+4F15:伕</span>
0184	<span class="old">U+4FC5:俅</span>	<span class="s3">U+4F70:佰</span>
0185	U+4FAE:侮
0186	U+4FAF:侯
0187	U+4FB5:侵
0188	U+4FB6:侶
0189	U+4FBF:便
0190	U+4FC2:係
0191	U+4FC3:促
0192	U+4FC4:俄
0193	U+4FCA:俊
0194	U+4FCE:俎
0195	U+4FCF:俏
0196	U+4FD0:俐
0197	U+4FD1:俑
0198	U+4FD7:俗
0199	U+4FD8:俘
<a id="s02"></a>
0200	U+4FDA:俚
0201	U+4FDB:俛	<span class="china2">U+4F61:佡</span>
0202	U+4FDD:保
0203	U+4FDF:俟
0204	U+4FE0:俠
0205	U+4FDE:俞
0206	U+5008:倈
0207	U+4FE1:信
0208	U+4FEE:修
0209	U+4FF6:俶
0210	U+5000:倀
0211	<span class="old">U+5005:倅</span>	<span class="s3">U+50CD:働</span>
0212	U+500C:倌
0213	U+502C:倬
0214	U+4FEF:俯
0215	U+4FF1:俱
0216	U+4FF3:俳
0217	U+4FF5:俵
0218	U+4FF8:俸
0219	U+4FFA:俺
0220	U+4FFE:俾
0221	U+5009:倉	<span class="china1">U+4ED3:仓</span>
0222	U+500B:個
0223	U+500D:倍
0224	U+5006:倆	<span class="china1">U+4FE9:俩</span>
0225	U+500F:倏
0226	U+5011:們
0227	U+5012:倒
0228	U+5016:倖
0229	U+5018:倘
0230	U+5019:候
0231	U+501A:倚
0232	U+501C:倜
0233	U+5002:倂
0234	U+501F:借
0235	U+5021:倡
0236	U+5023:倣
0237	U+503C:值
0238	U+5025:倥
0239	U+5026:倦
0240	U+5028:倨
0241	U+5029:倩
0242	U+502A:倪
0243	U+502B:倫
0244	U+502D:倭
0245	U+5048:偈
0246	U+504E:偎
0247	<span class="old">U+5072:偲</span>	<span class="s3">U+510D:儍</span>
0248	U+5041:偁
0249	U+5043:偃
0250	U+5047:假
0251	U+5049:偉
0252	U+504F:偏
0253	U+5055:偕
0254	U+505A:做
0255	U+505C:停
0256	U+5065:健
0257	U+506A:偪
0258	U+5074:側
0259	U+5075:偵
0260	U+5076:偶
0261	U+508E:傎	<span class="china2">U+4EEB:仫</span>
0262	<span class="old">U+5094:傔</span>	<span class="s3">U+5077:偷</span>
0263	U+5096:傖
0264	U+5080:傀
0265	U+5085:傅
0266	U+508D:傍
0267	U+5091:傑
0268	U+5092:傒
0269	<span class="old">U+506B:偫</span>	<span class="s2">U+5088:傈</span>
0270	U+5098:傘	<span class="china1">U+4F1E:伞</span>
0271	U+5099:備	<span class="china1">U+5907:备</span>
0272	U+509A:傚
0273	U+509E:傞
0274	U+509C:傜
0275	U+50AC:催
0276	U+50AD:傭
0277	U+50B2:傲
0278	U+50B3:傳
0279	U+50B4:傴
0280	U+50B5:債
0281	U+50B7:傷	<span class="china1">U+4F24:伤</span>
0282	U+50BE:傾
0283	U+50C2:僂
0284	U+50C5:僅	<span class="china1">U+4EC5:仅</span>
0285	U+50C7:僇
0286	U+50C9:僉
0287	<span class="old">U+50CA:僊</span>	<span class="s2">U+50F3:僳</span>
0288	U+50CF:像
0289	U+50F1:僱
0290	<span class="old">U+50CE:僎</span>	<span class="s2">U+20381:??</span>
0291	U+50E6:僦
0292	U+50E8:僨
0293	U+50E9:僩
0294	U+50D1:僑	<span class="china1">U+4FA8:侨</span>
0295	U+50D5:僕
0296	U+50D6:僖
0297	U+50DA:僚
0298	U+50DE:僞	<span class="china1">U+4F2A:伪</span>
0299	U+50E5:僥
<a id="s03"></a>
0300	U+50E7:僧
0301	U+50ED:僭
0302	U+50EE:僮
0303	U+5101:儁
0304	U+50F5:僵
0305	U+50F9:價	<span class="china1">U+4EF7:价</span>
0306	U+50FB:僻
0307	U+50FE:僾
0308	U+5100:儀	<span class="china1">U+4EEA:仪</span>
0309	U+5102:儂
0310	U+5104:億	<span class="china1">U+4EBF:亿</span>
0311	U+5106:儆
0312	U+5108:儈
0313	U+5109:儉
0314	U+510E:儎
0315	U+510C:儌
0316	U+50F0:僰
0317	U+510B:儋
0318	U+5107:儇
0319	U+5110:儐
0320	U+5112:儒
0321	U+5114:儔
0322	U+5115:儕
0323	U+5117:儗
0324	U+5118:儘
0325	U+5124:儤
0326	U+511F:償	<span class="china1">U+507F:偿</span>
0327	U+512A:優	<span class="china1">U+4F18:优</span>
0328	U+5132:儲
0329	U+5133:儳
0330	U+5137:儷
0331	U+513B:儻
0332	U+513C:儼
0333	U+5161:兡
0334	U+513F:儿
0335	U+5140:兀
0336	U+5141:允
0337	U+5143:元
0338	U+5144:兄
0339	U+5145:充
0340	U+5146:兆
0341	U+5148:先
0342	U+5149:光
0343	U+5147:兇
0344	U+514B:克
0345	U+514C:兌
0346	U+514D:免
0347	U+5154:兔
0348	U+5152:兒	<span class="china1">U+513F:儿</span>
0349	U+5155:兕
0350	U+5157:兗
0351	U+515C:兜
0352	U+5162:兢
0353	U+5163:兣
0354	U+5165:入
0355	U+5167:內
0356	U+5168:全
0357	U+5169:兩	<span class="china1">U+4E24:两</span>
0358	U+516A:兪
0359	<span class="s1">U+9208:鈈</span>
0360	U+516B:八
0361	U+516C:公
0362	U+516D:六
0363	U+516E:兮
0364	U+5171:共
0365	U+5175:兵
0366	U+5176:其
0367	U+5177:具
0368	U+5178:典
0369	U+517C:兼
0370	U+5180:冀
0371	<span class="s1">U+7CCD:糍</span>
0372	U+5182:冂
0373	U+5189:冉
0374	U+518C:册
0375	U+518D:再
0376	U+518F:冏
0377	U+5193:冓	<span class="china2">U+5187:冇</span>
0378	U+5191:冑
0379	U+5192:冒
0380	U+5195:冕
0381	<span class="s1">U+9479:鑹</span>
0382	U+5196:冖
0383	U+5197:冗
0384	U+519E:冞
0385	U+51A0:冠
0386	U+51A2:冢
0387	U+51A4:冤
0388	U+51A5:冥
0389	U+51AA:冪
0390	<span class="s1">U+8016:耖</span>
0391	U+51AB:冫
0392	U+51AC:冬
0393	U+51B0:冰
0394	U+51B2:冲
0395	U+51B1:冱
0396	U+51B6:冶
0397	U+51B7:冷
0398	U+51B8:冸	<span class="china2">U+51AE:冮</span>
0399	U+51BD:冽
<a id="s04"></a>
0400	U+51B5:况
0401	U+51C4:凄
0402	U+51C6:准
0403	U+51C8:凈
0404	U+51C9:凉
0405	<span class="old">U+51CA:凊</span>	<span class="s3">U+51BC:冼</span>
0406	U+51CB:凋
0407	U+51CC:凌
0408	U+51CD:凍	<span class="china1">U+51BB:冻</span>
0409	<span class="old">U+51CF:减</span>	<span class="s2">N/A:[?冫更]</span>
0410	U+51D1:凑
0411	U+51D3:凓
0412	U+51DC:凜
0413	U+51DD:凝
0414	U+51B3:决
0415	U+51E0:几
0416	U+51E1:凡
0417	U+51ED:凭
0418	U+51F1:凱
0419	U+51F3:凳
0420	U+51F0:凰
0421	<span class="s1">U+830C:茌</span>
0422	U+51F5:凵
0423	U+51F6:凶
0424	U+51F8:凸
0425	U+51F9:凹
0426	U+51F7:凷
0427	U+51FA:出
0428	U+51FD:函
0429	<span class="s1">U+83EA:菪</span>
0430	U+5200:刀
0431	U+5201:刁
0432	U+5203:刃
0433	U+5206:分
0434	U+5207:切
0435	U+5208:刈
0436	U+520A:刊
0437	U+520E:刎
0438	U+5211:刑
0439	U+5212:划
0440	U+5216:刖
0441	U+5217:列
0442	U+5228:刨
0443	U+521D:初
0444	U+5220:删
0445	U+5224:判
0446	U+5225:別	<span class="china1">U+522B:别</span>
0447	U+5226:刦
0448	U+5229:利
0449	U+5241:剁
0450	U+522E:刮
0451	U+5230:到
0452	U+5232:刲
0453	U+5233:刳
0454	U+5235:刵
0455	U+5236:制
0456	U+5237:刷
0457	U+5238:券
0458	U+5239:刹
0459	U+523A:刺
0460	U+524B:剋
0461	U+5243:剃
0462	U+5244:剄
0463	U+5247:則
0464	U+5249:剉
0465	U+524A:削
0466	U+523B:刻
0467	U+524D:前
0468	U+525C:剜
0469	<span class="old">U+525E:剞</span>	<span class="s3">U+524C:剌</span>
0470	U+5261:剡
0471	U+5254:剔
0472	U+5256:剖
0473	U+5257:剗
0474	U+525B:剛
0475	U+525D:剝
0476	U+5269:剩
0477	U+526A:剪
0478	U+526E:剮
0479	U+526F:副
0480	U+5272:割
0481	U+5274:剴
0482	U+5275:創
0483	U+5278:剸
0484	U+527D:剽
0485	U+527F:剿
0486	<span class="old">U+5282:劂</span>	<span class="s3">U+5260:剠</span>
0487	U+5283:劃
0488	U+5284:劄
0489	U+5287:劇	<span class="china1">U+5267:剧</span>
0490	U+5288:劈
0491	U+5289:劉	<span class="china1">U+5218:刘</span>
0492	U+528A:劊
0493	<span class="old">U+528C:劌</span>	<span class="s3">U+525A:剚</span>
0494	U+528D:劍
0495	U+5291:劑	<span class="china1">U+5242:剂</span>
0496	U+5293:劓
0497	<span class="old">U+5296:劖</span>	<span class="s3">U+5298:劘</span>
0498	<span class="old">U+529A:劚</span>	<span class="s3">U+5277:剷</span>
0499	U+5245:剅
<a id="s05"></a>
0500	U+529B:力
0501	U+529F:功
0502	U+52A0:加
0503	U+52A3:劣
0504	U+52A9:助
0505	U+52AA:努
0506	U+52AB:劫
0507	U+52AC:劬
0508	U+52AD:劭
0509	U+52B9:効
0510	U+52BB:劻
0511	U+52BE:劾
0512	U+52BC:劼
0513	U+52C1:勁
0514	U+52C3:勃
0515	U+52C5:勅	<span class="china2">U+52D0:勐</span>
0516	U+52C7:勇
0517	U+52C9:勉
0518	U+52CD:勍
0519	U+52D2:勒
0520	U+52D5:動	<span class="china1">U+52A8:动</span>
0521	U+52D6:勖
0522	U+52D8:勘
0523	U+52D9:務	<span class="china1">U+52A1:务</span>
0524	U+52DD:勝	<span class="china1">U+80DC:胜</span>
0525	U+52DE:勞	<span class="china1">U+52B3:劳</span>
0526	U+52E0:勠
0527	U+52DF:募
0528	U+52E2:勢	<span class="china1">U+52BF:势</span>
0529	U+52E3:勣
0530	U+52E4:勤
0531	U+52E6:勦
0532	U+52E9:勩
0533	U+52F0:勰
0534	U+52F3:勳
0535	U+52F1:勱
0536	U+52F5:勵	<span class="china1">U+52B1:励</span>
0537	U+52F7:勷
0538	U+52F8:勸	<span class="china1">U+529D:劝</span>
0539	<span class="s1">U+9340:鍀</span>
0540	U+52F9:勹
0541	U+52FA:勺
0542	U+52FB:勻
0543	U+52FF:勿
0544	U+5303:匃
0545	U+5305:包
0546	U+5308:匈
0547	U+530A:匊
0548	U+530D:匍
0549	U+530F:匏
0550	U+5310:匐
0551	U+52FE:勾
0552	U+5315:匕
0553	U+5316:化
0554	U+5317:北
0555	U+5319:匙
0556	<span class="s1">U+78B2:碲</span>
0557	U+531A:匚
0558	U+531C:匜
0559	U+531D:匝
0560	U+531F:匟
0561	U+5320:匠
0562	U+5321:匡
0563	U+5323:匣
0564	U+532A:匪
0565	U+532F:匯	<span class="china1">U+6C47:汇</span>
0566	U+5331:匱
0567	U+532D:匭
0568	U+5333:匳
0569	U+5335:匵
0570	<span class="s1">U+5576:啶</span>
0571	U+5338:匸
0572	U+5339:匹
0573	U+533E:匾
0574	U+533F:匿
0575	U+5340:區	<span class="china1">U+533A:区</span>
0576	<span class="s1">U+92A9:銩</span>
0577	U+5341:十
0578	U+5343:千
0579	U+5344:卄
0580	U+5345:卅
0581	U+5347:升
0582	U+5348:午
0583	U+5349:卉
0584	U+534A:半
0585	U+5351:卑
0586	U+5352:卒
0587	U+5353:卓
0588	U+5354:協	<span class="china1">U+534F:协</span>
0589	U+5357:南
0590	U+535A:博
0591	U+2717:?
0592	U+535C:卜
0593	U+535E:卞
0594	U+5360:占
0595	U+5361:卡
0596	U+5363:卣
0597	U+5366:卦
0598	<span class="s1">U+6C21:氡</span>
0599	U+5369:卩
<a id="s06"></a>
0600	U+536C:卬
0601	U+536D:卭
0602	U+536F:卯
0603	U+5370:印
0604	U+5371:危
0605	U+5372:卲
0606	U+5374:却
0607	U+5375:卵
0608	U+5377:卷
0609	U+5378:卸
0610	U+537A:卺
0611	U+537B:卻
0612	U+536E:卮
0613	U+537D:卽
0614	<span class="s3">U+5379:卹</span>
0615	U+537F:卿
0616	<span class="s1">U+8156:腖</span>
0617	U+5382:厂
0618	U+5384:厄
0619	U+538E:厎
0620	U+5393:厓
0621	U+5394:厔
0622	U+5398:厘
0623	U+5399:厙
0624	U+539A:厚
0625	U+539D:厝
0626	U+539F:原
0627	U+53A0:厠
0628	U+53A5:厥
0629	U+53AB:厫
0630	U+53AD:厭	<span class="china1">U+538C:厌</span>
0631	U+53AE:厮
0632	U+53B2:厲	<span class="china1">U+5389:厉</span>
0633	U+53A6:厦
0634	<span class="s1">U+80F4:胴</span>
0635	U+53B6:厶
0636	U+53B9:厹
0637	U+53BB:去
0638	U+53C1:叁
0639	U+53C3:參	<span class="china1">U+53C2:参</span>
0640	U+53C5:叅
0641	<span class="s1">U+5845:塅</span>
0642	U+53C8:又
0643	U+53C9:叉
0644	U+53CA:及
0645	U+53CB:友
0646	U+53CD:反
0647	U+53D4:叔
0648	U+53D6:取
0649	U+53D7:受
0650	U+53D9:叙
0651	U+53DB:叛
0652	U+53DF:叟
0653	U+53E1:叡
0654	U+53E2:叢	<span class="china1">U+4E1B:丛</span>
0655	U+53E0:叠
0656	U+53E3:口
0657	U+53E4:古
0658	U+53E5:句
0659	U+53E6:另
0660	U+53E8:叨
0661	U+53E9:叩
0662	U+53EA:只
0663	U+53EB:叫
0664	U+53EC:召
0665	U+53ED:叭
0666	U+53EE:叮
0667	U+53F1:叱
0668	U+53EF:可
0669	U+53F0:台
0670	U+53F2:史
0671	U+53F3:右
0672	U+53F5:叵
0673	U+53F6:叶
0674	U+53F8:司
0675	U+5401:吁
0676	U+5403:吃
0677	U+5404:各
0678	U+5408:合
0679	U+5409:吉
0680	U+540A:吊
0681	U+540C:同
0682	U+540D:名
0683	U+540E:后
0684	U+540F:吏
0685	U+5410:吐
0686	U+5411:向
0687	U+5413:吓
0688	U+5412:吒
0689	U+541B:君
0690	U+541D:吝
0691	U+541E:吞
0692	U+541F:吟
0693	U+5420:吠
0694	U+5426:否
0695	U+5429:吩
0696	U+5490:咐
0697	<span class="old">U+542A:吪</span>	<span class="s2">U+2F83B:<span style="font-family:UserDefine;">&#x2F83B;</span></span>
0698	U+542B:含
0699	U+542D:吭
<a id="s07"></a>
0700	U+542E:吮
0701	U+5448:呈
0702	U+5433:吳
0703	U+5435:吵
0704	U+5436:吶
0705	U+5438:吸
0706	U+5439:吹
0707	U+544A:告
0708	U+543B:吻
0709	U+543C:吼
0710	U+543E:吾
0711	U+5440:呀
0712	U+5442:呂
0713	U+5443:呃
0714	U+5446:呆
0715	U+5482:咂
0716	U+5462:呢
0717	U+5466:呦
0718	U+5467:呧	<span class="china2">U+544B:呋</span>
0719	U+5468:周
0720	U+5492:咒
0721	<span class="old">U+546D:呭</span>	<span class="s3">U+5427:吧</span>
0722	U+5471:呱
0723	U+546B:呫
0724	U+5473:味
0725	U+5475:呵
0726	U+5476:呶
0727	U+5477:呷
0728	U+547B:呻
0729	U+547C:呼
0730	U+547D:命
0731	U+5480:咀
0732	U+5484:咄
0733	U+5486:咆
0734	<span class="old">U+5488:咈</span>	<span class="s2">U+5495:咕</span>
0735	U+548C:和
0736	U+548E:咎
0737	U+548F:咏
0738	U+548B:咋
0739	<span class="old">U+548D:咍</span>	<span class="s3">U+5496:咖</span>
0740	<span class="old">U+54A1:咡</span>	<span class="s2">U+54CE:哎</span>
0741	U+54A4:咤
0742	<span class="old">U+54A2:咢</span>	<span class="s3">U+54CD:响</span>
0743	<span class="old">U+54A5:咥</span>	<span class="s3">U+54AA:咪</span>
0744	U+54A7:咧
0745	U+54A8:咨
0746	U+54AB:咫
0747	U+54AC:咬
0748	U+54AF:咯
0749	U+54B1:咱
0750	U+54B3:咳
0751	U+54B7:咷
0752	U+54B8:咸
0753	U+54BA:咺
0754	U+54BD:咽
0755	U+54C0:哀
0756	U+54C1:品
0757	U+54C2:哂
0758	U+54C4:哄
0759	<span class="old">U+54C6:哆</span>	<span class="s2">U+554A:啊</span>
0760	U+54C7:哇
0761	U+54C8:哈
0762	U+54C9:哉
0763	<span class="old">U+54BB:咻</span>	<span class="s2">U+54EA:哪</span>
0764	U+54BF:咿
0765	U+54E1:員
0766	U+54E5:哥
0767	<span class="old">U+550E:唎</span>	<span class="s3">U+5514:唔</span>
0768	U+54E6:哦
0769	U+54E9:哩
0770	U+54ED:哭
0771	U+54EE:哮
0772	U+54F2:哲
0773	U+54FA:哺
0774	U+54FC:哼
0775	U+54FD:哽
0776	U+54FF:哿
0777	U+5501:唁
0778	U+5506:唆
0779	U+5508:唈
0780	U+5509:唉
0781	U+5510:唐
0782	<span class="old">U+54E4:哤</span>	<span class="s3">U+5507:唇</span>
0783	U+54E8:哨
0784	<span class="old">U+5504:唄</span>	<span class="s2">U+5566:啦</span>
0785	U+550F:唏
0786	U+552E:售
0787	U+552F:唯
0788	U+5531:唱
0789	U+5533:唳
0790	U+553E:唾
0791	U+5541:啁
0792	U+5563:啣
0793	U+5544:啄
0794	U+5546:商
0795	U+554F:問
0796	U+5553:啓	<span class="china1">U+542F:启</span>
0797	U+5556:啖
0798	<span class="old">U+5557:啗</span>	<span class="s2">U+5565:啥</span>
0799	U+555C:啜
<a id="s08"></a>
0800	U+555E:啞	<span class="china1">U+54D1:哑</span>
0801	<span class="old">U+552A:唪</span>	<span class="s2">U+552C:唬</span>
0802	<span class="old">U+553C:唼</span>	<span class="s3">U+5564:啤</span>
0803	<span class="old">U+5550:啐</span>	<span class="s3">U+5561:啡</span>
0804	U+557B:啻
0805	U+557C:啼
0806	U+5581:喁
0807	U+5580:喀
0808	U+5582:喂
0809	U+5583:喃
0810	U+5584:善
0811	U+5586:喆
0812	U+5587:喇
0813	U+5588:喈
0814	U+5589:喉
0815	U+558A:喊
0816	U+558F:喏
0817	U+5593:喓
0818	U+558B:喋
0819	U+5591:喑
0820	U+5598:喘
0821	U+5599:喙
0822	U+559A:喚
0823	U+559C:喜
0824	U+559D:喝
0825	U+559E:喞
0826	U+55A7:喧
0827	U+55BB:喻
0828	U+55AA:喪	<span class="china1">U+4E27:丧</span>
0829	U+55AC:喬	<span class="china1">U+4E54:乔</span>
0830	U+55AE:單	<span class="china1">U+5355:单</span>
0831	U+557E:啾
0832	U+55C3:嗃	<span class="china2">U+55B9:喹</span>
0833	U+55C5:嗅
0834	U+55CE:嗎
0835	U+55C7:嗇	<span class="china1">U+556C:啬</span>
0836	U+55D1:嗑
0837	U+55D3:嗓
0838	U+55D4:嗔
0839	U+55DA:嗚
0840	U+55DB:嗛	<span class="china2">U+55EA:嗪</span>
0841	U+55DC:嗜
0842	U+55DF:嗟
0843	U+55E3:嗣
0844	U+55E4:嗤
0845	U+5594:喔
0846	U+559F:喟
0847	<span class="old">U+55A4:喤</span>	<span class="s2">U+55B2:喲</span>
0848	U+55AB:喫
0849	U+55AD:喭	<span class="china2">U+55E1:嗡</span>
0850	U+55C6:嗆
0851	U+55C9:嗉
0852	U+55D2:嗒
0853	<span class="old">U+55FF:嗿</span>	<span class="s3">U+560D:嘍</span>
0854	U+5605:嘅
0855	U+5606:嘆	<span class="china1">U+53F9:叹</span>
0856	U+5608:嘈
0857	U+5609:嘉
0858	U+560F:嘏
0859	<span class="old">U+5610:嘐</span>	<span class="s3">U+561B:嘛</span>
0860	<span class="old">U+5611:嘑</span>	<span class="s3">U+561C:嘜</span>
0861	U+5612:嘒
0862	U+5616:嘖
0863	U+5617:嘗	<span class="china1">U+5C1D:尝</span>
0864	U+5653:噓
0865	<span class="old">U+55F9:嗹</span>	<span class="s2">U+567B:噻</span>
0866	<span class="old">U+5602:嘂</span>	<span class="s3">U+568E:嚎</span>
0867	U+5620:嘠
0868	U+5614:嘔
0869	U+55F7:嗷
0870	U+55FD:嗽
0871	U+55FE:嗾
0872	U+562C:嘬
0873	U+5629:嘩
0874	U+55F6:嗶
0875	U+5630:嘰
0876	U+562F:嘯
0877	U+5632:嘲
0878	U+5634:嘴
0879	U+5635:嘵
0880	U+5636:嘶
0881	U+5637:嘷
0882	U+5639:嘹
0883	U+563B:嘻
0884	U+563F:嘿
0885	U+5649:噉
0886	U+564C:噌
0887	U+564D:噍
0888	U+564E:噎
0889	U+5662:噢
0890	U+564F:噏
0891	U+5664:噤
0892	U+5668:器
0893	U+5669:噩
0894	U+566A:噪
0895	U+566B:噫
0896	U+566C:噬
0897	U+566F:噯
0898	U+5672:噲
0899	U+5674:噴
<a id="s09"></a>
0900	U+5676:噶
0901	U+5665:噥
0902	U+5666:噦
0903	U+5678:噸	<span class="china1">U+5428:吨</span>
0904	U+5671:噱
0905	U+5680:嚀
0906	U+5685:嚅
0907	U+5687:嚇
0908	U+568F:嚏
0909	U+5699:嚙
0910	U+569A:嚚
0911	<span class="old">U+56B2:嚲</span>	<span class="s2">U+5538:唸</span>
0912	U+56C5:囅
0913	U+56A5:嚥
0914	U+56AC:嚬
0915	U+56AE:嚮
0916	<span class="old">U+56B3:嚳</span>	<span class="s2">U+5690:嚐</span>
0917	U+56B4:嚴	<span class="china1">U+4E25:严</span>
0918	U+56A8:嚨
0919	U+56B6:嚶
0920	U+56BC:嚼
0921	U+56C0:囀
0922	U+56C1:囁
0923	U+56C2:囂
0924	U+56B7:嚷
0925	U+56C9:囉
0926	U+56CA:囊
0927	U+56C8:囈
0928	U+56D1:囑
0929	U+56D3:囓
0930	U+53FB:叻
0931	U+56D7:囗
0932	U+56DE:回
0933	U+56DA:囚
0934	U+56DB:四
0935	U+56F1:囱
0936	U+56E0:因
0937	U+56E4:囤
0938	U+56F0:困
0939	U+56EB:囫
0940	U+56F7:囷
0941	U+56F9:囹
0942	U+56FA:固
0943	U+56FF:囿
0944	U+5703:圃
0945	U+5704:圄
0946	U+5708:圈
0947	U+5709:圉
0948	U+570B:國	<span class="china1">U+56FD:国</span>
0949	U+5705:圅
0950	U+5707:圇
0951	U+5702:圂	<span class="china2">U+5710:圐</span>
0952	U+56EE:囮	<span class="china2">U+5719:圙</span>
0953	U+570D:圍
0954	U+5712:園	<span class="china1">U+56ED:园</span>
0955	U+5713:圓
0956	U+5716:圖	<span class="china1">U+56FE:图</span>
0957	U+5718:團	<span class="china1">U+56E2:团</span>
0958	U+571C:圜
0959	U+5715:圕
0960	U+571F:土
0961	U+5728:在
0962	U+5729:圩
0963	U+572C:圬
0964	U+572D:圭
0965	U+572E:圮
0966	U+5730:地
0967	U+573B:圻
0968	U+5740:址
0969	<span class="old">U+577B:坻</span>	<span class="s3">U+573E:圾</span>
0970	U+575F:坟
0971	U+5747:均
0972	U+574A:坊
0973	U+574D:坍
0974	U+574E:坎
0975	U+574F:坏
0976	U+5750:坐
0977	U+5751:坑
0978	U+5742:坂
0979	U+574C:坌
0980	U+5761:坡
0981	U+5764:坤
0982	U+5766:坦
0983	U+576D:坭
0984	<span class="old">U+5775:坵</span>	<span class="s2">U+5769:坩</span>
0985	U+5777:坷
0986	U+577C:坼
0987	U+5782:垂
0988	U+576A:坪
0989	U+576B:坫
0990	U+5770:坰
0991	U+5773:坳
0992	U+578B:型
0993	U+5793:垓
0994	U+579D:垝	<span class="china2">U+576C:坬</span>
0995	U+57A0:垠
0996	U+57A2:垢
0997	U+57A3:垣
0998	<span class="old">U+579E:垞</span>	<span class="s3">U+5783:垃</span>
0999	<span class="old">U+57A4:垤</span>	<span class="s3">U+576F:坯</span>
<a id="s10"></a>
1000	U+579C:垜
1001	<span class="old">U+579A:垚</span>	<span class="s3">U+5768:坨</span>
1002	U+57C3:埃
1003	U+57CB:埋
1004	U+57CE:城
1005	U+57D2:埒
1006	<span class="old">U+57C2:埂</span>	<span class="s3">U+57AE:垮</span>
1007	U+57CF:埏
1008	U+57DF:域
1009	U+57E0:埠
1010	<span class="old">U+57E6:埦</span>	<span class="s2">U+57A7:垧</span>
1011	U+57ED:埭
1012	<span class="old">U+57F6:埶</span>	<span class="s2">U+57A1:垡</span>
1013	U+57F7:執	<span class="china1">U+6267:执</span>
1014	U+57F9:培
1015	U+57FA:基
1016	U+5802:堂
1017	U+5805:堅	<span class="china1">U+575A:坚</span>
1018	U+5806:堆
1019	U+580A:堊	
1020	U+57E4:埤
1021	U+57F4:埴
1022	U+57F5:埵
1023	U+57F8:埸
1024	U+5803:堃
1025	U+5819:堙
1026	U+581E:堞
1027	U+5821:堡
1028	U+5820:堠
1029	U+5824:堤
1030	U+582A:堪
1031	U+582F:堯	<span class="china1">U+5C27:尧</span>
1032	U+5831:報	<span class="china1">U+62A5:报</span>
1033	<span class="old">U+5832:堲</span>	<span class="s3">U+57D4:埔</span>
1034	U+5834:場
1035	U+5835:堵
1036	<span class="old">U+5827:堧</span>	<span class="s3">U+57DD:埝</span>
1037	U+5830:堰
1038	U+5826:堦	<span class="china2">U+57BE:垾</span>
1039	U+584D:塍
1040	U+584A:塊	<span class="china1">U+5757:块</span>
1041	U+584B:塋
1042	U+584C:塌
1043	U+5851:塑
1044	U+5854:塔
1045	U+5893:墓
1046	U+585A:塚
1047	U+5857:塗
1048	U+5858:塘
1049	U+585E:塞
1050	U+5861:塡
1051	U+5862:塢
1052	U+584F:塏
1053	U+5864:塤
1054	U+5852:塒
1055	U+584E:塎	<span class="china2">U+583C:堼</span>
1056	<span class="old">U+5853:塓</span>	<span class="s3">～U+57E7:埧</span>
1057	U+5875:塵	<span class="china1">U+5C18:尘</span>
1058	U+5879:塹
1059	U+587C:塼
1060	U+587E:塾
1061	U+587F:塿	<span class="china2">U+5842:塂</span>
1062	U+5880:墀
1063	U+5881:墁
1064	U+5883:境
1065	U+5885:墅
1066	U+5889:墉
1067	U+588A:墊	<span class="china1">U+57AB:垫</span>
1068	U+5884:墄
1069	<span class="old">U+5848:塈</span>	<span class="s2">U+57EB:埫</span>
1070	U+5890:墐
1071	U+589C:墜
1072	<span class="old">U+589D:墝</span>	<span class="s3">U+583F:堿</span>
1073	U+589E:增
1074	U+589F:墟
1075	U+58A8:墨
1076	U+58A9:墩
1077	U+58AE:墮	<span class="china1">U+5815:堕</span>
1078	U+58BA:墺
1079	U+58B3:墳
1080	<span class="old">U+58A0:墠</span>	<span class="s2">U+5844:塄</span>
1081	<span class="old">U+58AB:墫</span>	<span class="s2">U+58EA:壪</span>
1082	U+58A6:墦	<span class="china2">U+5888:墈</span>
1083	U+58BE:墾	<span class="china1">U+57A6:垦</span>
1084	U+58C1:壁
1085	U+58C5:壅
1086	U+58C7:壇	<span class="china1">U+575B:坛</span>
1087	U+21484:??
1088	U+58CE:壎
1089	U+58D1:壑
1090	U+58D3:壓	<span class="china1">U+538B:压</span>
1091	U+58D5:壕
1092	U+58D6:壖
1093	U+58D8:壘	<span class="china1">U+5792:垒</span>
1094	U+58D9:壙
1095	U+58DE:壞
1096	U+58DF:壟
1097	U+58DA:壚
1098	U+58DC:壜
1099	U+58E4:壤
<a id="s11"></a>
1100	U+58E9:壩
1101	U+5733:圳
1102	U+58EB:士
1103	U+58EC:壬
1104	U+58EF:壯	<span class="china1">U+58EE:壮</span>
1105	U+58F9:壹
1106	U+58FA:壺	<span class="china1">U+58F6:壶</span>
1107	U+58FB:壻
1108	U+58FD:壽	<span class="china1">U+5BFF:寿</span>
1109	U+58FC:壼
1110	<span class="s1">U+6934:椴</span>
1111	U+5902:夂
1112	U+5906:夆
1113	<span class="s1">U+7C6A:籪</span>
1114	U+590A:夊
1115	U+590F:夏
1116	<span class="s1">U+7818:砘</span>
1117	～U+2D431:<span style="font-family:UserDefine;">&#x2D431;</span>
1118	<span class="s1">U+8DFA:跺</span>
1119	U+5915:夕
1120	U+5916:外
1121	U+5919:夙
1122	U+591A:多
1123	U+591C:夜
1124	U+5920:夠
1125	U+5922:夢	<span class="china1">U+68A6:梦</span>
1126	U+5924:夤
1127	U+5925:夥
1128	<span class="s1">U+5A40:婀</span>
1129	U+5927:大
1130	U+592D:夭
1131	U+5929:天
1132	U+592A:太
1133	U+592B:夫
1134	U+592C:夬
1135	U+592E:央
1136	U+5931:失
1137	U+592F:夯
1138	U+5937:夷
1139	U+5938:夸
1140	U+593E:夾	<span class="china1">U+5939:夹</span>
1141	U+5944:奄
1142	U+5947:奇
1143	U+5948:奈
1144	U+5949:奉
1145	U+594E:奎
1146	U+594F:奏
1147	U+5950:奐
1148	U+5951:契
1149	U+5954:奔
1150	U+5955:奕
1151	U+5953:奓
1152	U+5957:套
1153	U+595A:奚
1154	<span class="s1">U+92E8:鋨</span>
1155	U+5958:奘
1156	U+5960:奠
1157	U+5961:奡
1158	U+5962:奢
1159	U+5967:奧
1160	U+5969:奩
1161	U+596A:奪	<span class="china1">U+593A:夺</span>
1162	U+596C:奬	<span class="china1">U+5956:奖</span>
1163	U+596D:奭
1164	U+596E:奮	<span class="china1">U+594B:奋</span>
1165	U+5940:奀
1166	U+5973:女
1167	U+5974:奴
1168	U+5976:奶
1169	U+5978:奸
1170	U+597D:好
1171	U+5981:妁
1172	U+5982:如
1173	U+5983:妃
1174	U+5984:妄
1175	U+598A:妊
1176	U+5992:妒
1177	U+59F8:姸
1178	U+5993:妓
1179	U+5996:妖
1180	U+5997:妗
1181	U+5999:妙
1182	U+599D:妝	<span class="china1">U+5986:妆</span>
1183	U+59A3:妣
1184	U+59A4:妤
1185	U+59A5:妥
1186	U+59A8:妨
1187	U+59AF:妯
1188	U+59B9:妹
1189	U+59BB:妻
1190	U+59BE:妾
1191	U+59C6:姆
1192	U+59CA:姊
1193	U+59CB:始
1194	U+59D7:姗
1195	U+59D0:姐
1196	U+59D1:姑
1197	U+59D2:姒
1198	U+59D3:姓
1199	U+59B2:妲
<a id="s12"></a>
1200	U+59AE:妮
1201	U+59D4:委
1202	U+59DA:姚
1203	U+59DC:姜
1204	U+59DD:姝
1205	U+59DE:姞
1206	U+59D9:姙
1207	U+59E3:姣
1208	U+59E4:姤
1209	U+59E5:姥
1210	U+59E8:姨
1211	U+59E6:姦
1212	U+59EA:姪
1213	U+59EC:姬
1214	U+59C5:姅
1215	U+59FB:姻
1216	U+5A03:娃
1217	U+59FF:姿
1218	U+5A01:威
1219	U+5A09:娉
1220	U+59EE:姮
1221	U+59F1:姱
1222	U+5A0C:娌
1223	U+5A11:娑
1224	U+5A18:娘
1225	U+5A1B:娛
1226	U+5A1C:娜
1227	U+5A1F:娟
1228	U+5A20:娠
1229	U+5A23:娣
1230	U+5A25:娥
1231	U+5A29:娩
1232	U+5A13:娓
1233	U+5A3C:娼
1234	U+59F9:姹
1235	U+5A36:娶
1236	U+5A41:婁	<span class="china1">U+5A04:娄</span>
1237	U+5A46:婆
1238	U+5A49:婉
1239	U+5A4A:婊
1240	U+5A55:婕
1241	U+5A5A:婚
1242	U+5A62:婢
1243	U+5A63:婣
1244	U+5A66:婦	<span class="china1">U+5987:妇</span>
1245	U+5A6A:婪
1246	U+5A6D:婭
1247	<span class="old">U+5A35:娵</span>	<span class="s3">U+5979:她</span>
1248	<span class="old">U+5A50:婐</span>	<span class="s2">U+59B3:妳</span>
1249	<span class="old">U+5A5E:婞</span>	<span class="s3">U+5A7C:婼</span>
1250	U+5A77:婷
1251	U+5A7A:婺
1252	U+5A92:媒
1253	U+5A9A:媚
1254	U+5A9B:媛
1255	U+5A9F:媟
1256	U+5AA2:媢
1257	U+5AA7:媧
1258	<span class="old">U+5A8A:媊</span>	<span class="s2">U+5AAC:媬</span>
1259	U+5A95:媕
1260	U+5A96:媖
1261	U+5AB3:媳
1262	U+5AB5:媵
1263	U+5AB8:媸
1264	U+5AAA:媪
1265	U+5ABD:媽
1266	U+5ABE:媾
1267	U+5ABF:媿
1268	U+5AC1:嫁
1269	U+5AC2:嫂
1270	U+5AC4:嫄
1271	U+5AC9:嫉
1272	U+5ACB:嫋
1273	U+5ACC:嫌
1274	U+5AD3:嫓
1275	U+5ABA:媺
1276	U+5AD6:嫖
1277	U+5AD7:嫗
1278	U+5AE0:嫠
1279	U+5AE1:嫡
1280	U+5AE3:嫣
1281	U+5AE6:嫦
1282	U+5AE9:嫩
1283	U+5AEA:嫪
1284	U+5AD8:嫘
1285	U+5ADA:嫚
1286	U+5ADC:嫜
1287	U+5AEB:嫫
1288	U+5AFA:嫺
1289	U+5B00:嬀
1290	U+5B08:嬈
1291	U+5B09:嬉
1292	U+5B0B:嬋
1293	U+5B0C:嬌
1294	U+5B03:嬃
1295	U+5B16:嬖
1296	U+5B17:嬗
1297	U+5B19:嬙
1298	U+5B1B:嬛
1299	U+5B34:嬴
<a id="s13"></a>
1300	U+5B2A:嬪
1301	U+5B37:嬷
1302	U+5B2D:嬭
1303	U+5B32:嬲
1304	U+5B3E:嬾
1305	U+5B30:嬰
1306	U+5B38:嬸
1307	U+5B40:孀
1308	U+5B45:孅
1309	U+5B4C:孌
1310	U+599E:妞
1311	U+5B50:子
1312	U+5B51:孑
1313	U+5B54:孔
1314	U+5B55:孕
1315	<span class="old">U+5B56:孖</span>	<span class="s3">U+5B53:孓</span>
1316	U+5B57:字
1317	U+5B58:存
1318	U+5B5A:孚
1319	U+5B5B:孛
1320	U+5B5C:孜
1321	U+5B5D:孝
1322	U+5B5F:孟
1323	U+5B63:季
1324	U+5B64:孤
1325	U+5B65:孥
1326	U+5B69:孩
1327	U+5B6B:孫	<span class="china1">U+5B59:孙</span>
1328	U+5B70:孰
1329	U+5B71:孱
1330	U+5B73:孳
1331	U+5B78:學	<span class="china1">U+5B66:学</span>
1332	U+5B7A:孺
1333	U+5B7C:孼
1334	U+5B7F:孿
1335	U+5B75:孵
1336	U+5B80:宀
1337	U+5B81:宁
1338	U+5B83:它
1339	U+5B84:宄
1340	U+5B82:宂
1341	U+5B85:宅
1342	U+5B87:宇
1343	U+5B88:守
1344	U+5B89:安
1345	U+5B8B:宋
1346	U+5B8C:完
1347	U+5B8F:宏
1348	U+5B93:宓
1349	U+5B95:宕
1350	U+5B97:宗
1351	U+5B98:官
1352	U+5B99:宙
1353	U+5B9A:定
1354	U+5B9B:宛
1355	U+5B9C:宜
1356	U+5BA2:客
1357	U+5BA3:宣
1358	U+5BA4:室
1359	U+5BA5:宥
1360	U+5BA6:宦
1361	U+5BAC:宬
1362	U+5BAE:宮
1363	U+5BB0:宰
1364	U+5BB3:害
1365	U+5BB4:宴
1366	U+5BB5:宵
1367	U+5BB6:家
1368	U+5BB8:宸
1369	U+5BB9:容
1370	U+68A5:梥
1371	U+5BC0:寀
1372	U+5BBF:宿
1373	～U+5BC1:寁
1374	U+5BC2:寂
1375	U+5BC3:寃
1376	U+5BC4:寄
1377	U+5BC5:寅
1378	U+5BC6:密
1379	U+5BC7:寇
1380	U+5BE7:寧
1381	U+5BCC:富
1382	U+5BD0:寐
1383	U+5BD2:寒
1384	U+5BD3:寓
1385	U+5BD4:寔
1386	U+5BD6:寖
1387	U+5BD8:寘
1388	U+5BCE:寎
1389	U+5BDE:寞
1390	U+5BDF:察
1391	U+5BE1:寡
1392	U+5BE2:寢	<span class="china1">U+5BDD:寝</span>
1393	U+5BE4:寤
1394	U+5BE5:寥
1395	U+5BE6:實	<span class="china1">U+5B9E:实</span>
1396	U+5BE8:寨
1397	U+5BE0:寠
1398	U+5BD9:寙
1399	U+5BE9:審	<span class="china1">U+5BA1:审</span>
<a id="s14"></a>
1400	U+5BEB:寫	<span class="china1">U+5199:写</span>
1401	U+5BEC:寬
1402	U+5BEE:寮
1403	U+5BF0:寰
1404	U+5BF5:寵
1405	U+5BF3:寳	<span class="china1">U+5B9D:宝</span>
1406	U+5BA7:宧
1407	U+5BF8:寸
1408	U+5BFA:寺
1409	U+5C01:封
1410	U+5C04:射
1411	<span class="c0">U+5C05:尅</span>
1412	U+5C07:將	<span class="china1">U+5C06:将</span>
1413	U+5C08:專	<span class="china1">U+4E13:专</span>
1414	U+5C09:尉
1415	U+5C0A:尊
1416	U+5C0B:尋	<span class="china1">U+5BFB:寻</span>
1417	U+5C0D:對	<span class="china1">U+5BF9:对</span>
1418	U+5C0E:導	<span class="china1">U+5BFC:导</span>
1419	<span class="s1">U+84BD:蒽</span>
1420	U+5C0F:小
1421	U+5C11:少
1422	U+5C14:尔
1423	U+5C16:尖
1424	U+5C1A:尚
1425	U+5C20:尠
1426	<span class="old">U+5C1F:尟</span>	<span class="s2">U+5C1E:尞</span>
1427	U+5C15:尕
1428	U+5C22:尢
1429	U+5C24:尤
1430	U+5C28:尨
1431	～U+5C2A:尪
1432	U+5C31:就
1433	U+5C30:尰
1434	U+5C32:尲
1435	U+5C2C:尬
1436	<span class="s1">U+927A:鉺</span>
1437	U+5C38:尸
1438	U+5C39:尹
1439	U+5C3A:尺
1440	U+5C3B:尻
1441	U+5C3C:尼
1442	U+5C3E:尾
1443	U+5C3F:尿
1444	U+5C40:局
1445	U+5C41:屁
1446	U+5C45:居
1447	U+5C46:屆
1448	U+5C48:屈
1449	U+5C49:屉
1450	U+5C4B:屋
1451	U+5C4D:屍
1452	U+5C4E:屎
1453	U+5C50:屐
1454	U+5C51:屑
1455	U+5C55:展
1456	U+5C5B:屛
1457	U+5C5D:屝
1458	U+5C60:屠
1459	U+5C62:屢	<span class="china1">U+5C61:屡</span>
1460	U+5C63:屣
1461	U+5C64:層	<span class="china1">U+5C42:层</span>
1462	U+5C65:履
1463	U+5C67:屧
1464	U+5C68:屨
1465	U+5C69:屩
1466	U+5C6C:屬
1467	U+5C6D:屭
1468	<span class="s1">U+7829:砩</span>
1469	U+5C6E:屮
1470	U+5C6F:屯
1471	U+5CB3:岳
1472	U+5C71:山
1473	U+5C79:屹
1474	U+21D3E:??
1475	<span class="old">U+5C7C:屼</span>	<span class="s2">U+5CC1:峁</span>
1476	U+5C8C:岌
1477	U+5C90:岐
1478	U+5C91:岑
1479	U+5C94:岔
1480	<span class="old">U+5C85:岅</span>	<span class="s2">U+5CFF:峿</span>
1481	U+5CA1:岡
1482	U+5CA2:岢
1483	<span class="old">U+5CA8:岨</span>	<span class="s3">U+5CEB:峫</span>
1484	U+5CA9:岩
1485	U+5CAB:岫
1486	U+5CB1:岱
1487	U+5CB5:岵
1488	U+5CB7:岷
1489	U+5CB8:岸
1490	U+5CA3:岣
1491	U+5CD2:峒
1492	U+5CD9:峙
1493	U+5CCB:峋
1494	U+5CE8:峨
1495	U+5CED:峭
1496	U+5CEF:峯
1497	U+5CF6:島
1498	U+5CFB:峻
1499	U+5CFD:峽
<a id="s15"></a>
1500	U+5CD3:峓
1501	U+5CF4:峴
1502	<span class="old">U+5CF9:峹</span>	<span class="s3">U+5CEA:峪</span>
1503	<span class="old">U+5CE2:峢</span>	<span class="s2">U+5D0D:崍</span>
1504	U+5D07:崇
1505	U+5D0E:崎
1506	U+5D10:崐	<span class="china2">U+5CBD:岽</span>
1507	U+5D11:崑
1508	U+5D14:崔
1509	U+5D16:崖
1510	U+5D19:崙
1511	U+5D17:崗
1512	U+5D1B:崛
1513	U+5D22:崢
1514	U+5D29:崩
1515	U+5D1A:崚
1516	U+5D27:崧
1517	U+5D26:崦
1518	U+5D47:嵇
1519	<span class="old">U+5D3F:崿</span>	<span class="s3">U+5D06:崆</span>
1520	U+5D4B:嵋
1521	U+5D6B:嵫
1522	U+5D4A:嵊
1523	U+5D4C:嵌
1524	U+5D36:崶	<span class="china2">U+5CE7:峧</span>
1525	U+5D4E:嵎
1526	U+5D50:嵐
1527	U+5D52:嵒	<span class="china2">U+5D00:崀</span>
1528	U+5D31:崱	<span class="china2">U+5D05:崅</span>
1529	U+5D69:嵩
1530	U+5D81:嶁
1531	U+5D6C:嵬
1532	U+5D6F:嵯
1533	U+5D7E:嵾	<span class="china2">U+5D0C:崌</span>
1534	U+5D82:嶂
1535	U+5D84:嶄
1536	U+5D87:嶇
1537	U+5D92:嶒
1538	U+5D94:嶔
1539	U+5DB8:嶸
1540	U+5DA0:嶠
1541	<span class="old">U+5D9E:嶞</span>	<span class="s3">U+5D24:崤</span>
1542	U+5DA7:嶧
1543	U+5D99:嶙
1544	U+5DB7:嶷
1545	U+5DBA:嶺	<span class="china1">U+5CAD:岭</span>
1546	U+5DBC:嶼	<span class="china1">U+5C7F:屿</span>
1547	U+5DBD:嶽	<span class="china2">U+5D3E:崾</span>
1548	U+5DC9:巉
1549	<span class="old">U+5DCB:巋</span>	<span class="s2">U+5D5B:嵛</span>
1550	U+5DCD:巍
1551	U+5DD2:巒
1552	U+5DD8:巘	<span class="china2">U+5D85:嶅</span>
1553	U+5DD3:巓
1554	U+5DD6:巖
1555	U+5D97:嶗
1556	U+5DDB:巛
1557	U+5DDD:川
1558	U+5DDE:州
1559	U+5DE1:巡
1560	U+5DE2:巢
1561	<span class="s1">U+9428:鐨</span>
1562	U+5DE5:工
1563	U+5DE6:左
1564	U+5DE7:巧
1565	U+5DE8:巨
1566	U+5DEB:巫
1567	U+5DEE:差
1568	<span class="s1">U+915A:酚</span>
1569	U+5DF1:己
1570	U+5DF3:巳
1571	U+5DF2:已
1572	U+5DF4:巴
1573	U+5DF5:巵
1574	U+5DF7:巷
1575	U+5DFD:巽
1576	<span class="s1">U+91D3:釓</span>
1577	U+5DFE:巾
1578	U+5E00:帀
1579	U+5E02:市
1580	U+5E03:布
1581	U+5E06:帆
1582	U+5E0B:帋
1583	U+5E11:帑
1584	U+5E15:帕
1585	U+5E0C:希
1586	U+5E16:帖
1587	U+5E17:帗
1588	U+5E18:帘
1589	U+5E19:帙
1590	U+5E1A:帚
1591	U+5E1B:帛
1592	U+5E14:帔
1593	U+5E1D:帝
1594	U+5E32:帲
1595	U+5E1F:帟
1596	U+5E25:帥	<span class="china1">U+5E05:帅</span>
1597	U+5E2B:師	<span class="china1">U+5E08:师</span>
1598	U+5E2D:席
1599	U+5E28:帨
<a id="s16"></a>
1600	U+5E33:帳
1601	U+5E36:帶	<span class="china1">U+5E26:带</span>
1602	U+5E37:帷
1603	U+5E38:常
1604	U+5E3D:帽
1605	U+5E43:幃
1606	U+5E44:幄
1607	U+5E45:幅
1608	U+5E40:幀
1609	U+5E4B:幋
1610	U+5E4C:幌
1611	U+5E54:幔
1612	U+5E55:幕
1613	U+5E57:幗
1614	U+5E58:幘
1615	U+5E5F:幟	<span class="china1">U+5E1C:帜</span>
1616	U+5E61:幡
1617	U+5E62:幢
1618	U+5E63:幣	<span class="china1">U+5E01:币</span>
1619	U+5E6A:幪
1620	U+5E6B:幫	<span class="china1">U+5E2E:帮</span>
1621	U+5E6C:幬
1622	U+5E6D:幭
1623	U+5E6F:幯
1624	U+5E70:幰
1625	U+5E5B:幛
1626	U+5E72:干
1627	U+5E73:平
1628	U+5E74:年
1629	U+5E77:幷
1630	U+5E78:幸
1631	U+5E79:幹
1632	<span class="s1">U+77F8:矸</span>
1633	U+5E7A:幺
1634	U+5E7B:幻
1635	U+5E7C:幼
1636	U+5E7D:幽
1637	U+5E7E:幾
1638	<span class="s1">U+9150:酐</span>
1639	U+5E7F:广
1640	U+5E80:庀
1641	<span class="old">U+5E84:庄</span>	<span class="s2">U+5EB9:庹</span>
1642	U+5E87:庇
1643	U+5E8A:床
1644	U+5E8B:庋
1645	U+5E8F:序
1646	U+5E95:底
1647	U+5E96:庖
1648	U+5E97:店
1649	U+5E9A:庚
1650	U+5E9C:府
1651	U+5EA0:庠
1652	U+5EA5:庥
1653	U+5EA6:度
1654	U+5EA7:座
1655	U+5EAB:庫
1656	U+5EAD:庭
1657	U+5EB3:庳
1658	U+5EB5:庵
1659	U+5EB6:庶
1660	U+5EB7:康
1661	U+5EB8:庸
1662	U+5EBE:庾
1663	U+5EAC:庬
1664	U+5EB4:庴
1665	U+5EC1:廁
1666	U+5EC2:廂
1667	U+5ECC:廌
1668	U+5ED1:廑
1669	U+5EC8:廈
1670	U+5EC9:廉
1671	U+5ECA:廊
1672	U+5ECB:廋
1673	U+5ED0:廐
1674	U+5ED3:廓
1675	U+5ED6:廖
1676	U+5EDA:廚
1677	U+5ED5:廕
1678	U+5EDD:廝
1679	～U+5EDB:廛
1680	U+5EDF:廟	<span class="china1">U+5E99:庙</span>
1681	U+5EE0:廠
1682	U+5EE1:廡
1683	U+5EE2:廢
1684	U+5EE3:廣
1685	U+5EE8:廨
1686	U+5EE9:廩
1687	U+5EEC:廬	<span class="china1">U+5E90:庐</span>
1688	U+5EF1:廱
1689	U+5EF3:廳	<span class="china1">U+5385:厅</span>
1690	U+9F90:龐
1691	<span class="s1">U+92EF:鋯</span>
1692	U+5EF4:廴
1693	U+5EF6:延
1694	U+5EF7:廷
1695	U+5EF9:廹
1696	U+5EFA:建
1697	U+5EFB:廻
1698	U+5EFC:廼
1699	U+5EFE:廾
<a id="s17"></a>
1700	U+5EFF:廿
1701	U+5F01:弁
1702	U+5F04:弄
1703	U+5F07:弇
1704	U+5F08:弈
1705	U+5F0A:弊
1706	<span class="s1">U+831B:茛</span>
1707	U+5F0B:弋
1708	U+5F0D:弍
1709	U+5F0F:式
1710	U+5F12:弒
1711	<span class="s1">U+7014:瀔</span>
1712	U+5F13:弓
1713	U+5F14:弔
1714	U+5F15:引
1715	U+5F17:弗
1716	U+5F1B:弛
1717	U+5F1F:弟
1718	U+5F22:弢
1719	U+5F23:弣
1720	U+5F26:弦
1721	U+5F27:弧
1722	U+5F29:弩
1723	U+5F24:弤
1724	U+5F28:弨
1725	U+5F2D:弭
1726	U+5F31:弱
1727	U+5F30:弰
1728	U+5F35:張
1729	U+5F44:彄
1730	U+5F37:強
1731	U+5F38:弸
1732	U+5F3C:弼
1733	U+5F40:彀
1734	U+5F48:彈
1735	U+5F4A:彊
1736	U+5F4C:彌	<span class="china1">U+5F25:弥</span>
1737	U+5F4E:彎	<span class="china1">U+5F2F:弯</span>
1738	U+5F18:弘
1739	U+5F50:彐
1740	U+5F56:彖
1741	U+5F57:彗
1742	U+5F58:彘
1743	U+5F59:彙
1744	U+5F5D:彝
1745	U+5F60:彠
1746	<span class="s1">U+81CC:臌</span>
1747	U+5F61:彡
1748	U+5F62:形
1749	U+5F64:彤
1750	U+5F65:彥
1751	U+5F67:彧
1752	U+5F69:彩
1753	U+5F6A:彪
1754	U+5F6B:彫
1755	U+5F6C:彬
1756	U+5F6D:彭
1757	U+5F70:彰
1758	U+5F71:影
1759	U+5F72:彲
1760	<span class="s1">U+927F:鉿</span>
1761	U+5F73:彳
1762	U+5F77:彷
1763	U+5F79:役
1764	U+5F7C:彼
1765	U+5F7F:彿
1766	U+5F80:往
1767	U+5F81:征
1768	U+5F82:徂
1769	U+5F85:待
1770	U+5F87:徇
1771	U+5F88:很
1772	U+5F89:徉
1773	U+5F8A:徊
1774	U+5F8B:律
1775	U+5F8C:後
1776	U+5F90:徐
1777	U+5F91:徑
1778	U+5F92:徒
1779	U+5F97:得
1780	U+5F98:徘
1781	U+5F99:徙
1782	U+5F9C:徜
1783	U+5F9E:從	<span class="china1">U+4ECE:从</span>
1784	U+5FA0:徠
1785	～U+5FA1:御
1786	U+5FA7:徧
1787	U+5FA8:徨
1788	U+5FA9:復	<span class="china1">U+590D:复</span>
1789	U+5FAA:循
1790	U+5FAC:徬
1791	U+5FAD:徭
1792	U+5FAE:微
1793	U+5FAF:徯
1794	U+5FB5:徵
1795	U+5FB7:德
1796	U+5FB9:徹	<span class="china1">U+5F7B:彻</span>
1797	U+5FBC:徼
1798	U+5FBD:徽
1799	<span class="s1">U+7113:焓</span>
<a id="s18"></a>
1800	U+5FC3:心
1801	U+5FC5:必
1802	U+5FC9:忉
1803	U+5FCC:忌
1804	U+5FCD:忍
1805	U+5FD2:忒
1806	U+5FD6:忖
1807	U+5FD7:志
1808	U+5FD8:忘
1809	U+5FD0:忐
1810	U+5FD1:忑
1811	U+5FD9:忙
1812	U+5FDD:忝
1813	U+5FE0:忠
1814	U+5FE1:忡
1815	<span class="old">U+5FEA:忪</span>	<span class="s3">U+606C:恬</span>
1816	U+5FEB:快
1817	U+5FED:忭
1818	U+5FEE:忮
1819	U+5FF5:念
1820	U+5FF1:忱
1821	U+5FF8:忸
1822	U+5FE4:忤
1823	U+5FFB:忻
1824	U+5FFD:忽
1825	U+5FFF:忿
1826	U+600D:怍
1827	U+600E:怎
1828	U+600F:怏
1829	U+6012:怒
1830	U+6015:怕
1831	U+6016:怖
1832	U+6017:怗
1833	U+6019:怙
1834	U+601B:怛
1835	U+601D:思
1836	U+6020:怠
1837	U+6021:怡
1838	U+6025:急
1839	U+6026:怦
1840	U+6027:性
1841	U+6028:怨
1842	U+6029:怩
1843	U+602A:怪
1844	U+602B:怫
1845	U+602F:怯
1846	U+6031:怱
1847	U+6035:怵
1848	<span class="old">U+6008:怈</span>	<span class="s2">N/A:[?她心]</span>
1849	<span class="old">U+6033:怳</span>	<span class="s3">U+60A8:您</span>
1850	U+6014:怔
1851	U+6041:恁
1852	U+6042:恂
1853	U+6043:恃
1854	U+6046:恆
1855	<span class="old">U+6047:恇</span>	<span class="s3">U+60E6:惦</span>
1856	U+604C:恌
1857	U+604D:恍
1858	U+6050:恐
1859	U+6055:恕
1860	U+6059:恙
1861	U+605A:恚
1862	U+605D:恝
1863	U+6062:恢
1864	U+6063:恣
1865	U+6064:恤
1866	U+6065:恥
1867	U+6067:恧
1868	U+6068:恨
1869	U+6069:恩
1870	U+606A:恪
1871	U+606B:恫
1872	U+606D:恭
1873	U+606F:息
1874	U+6070:恰
1875	U+6083:悃
1876	U+6049:恉
1877	U+6084:悄
1878	U+6085:悅
1879	U+608C:悌
1880	U+608D:悍
1881	U+6092:悒
1882	U+6094:悔
1883	U+6096:悖
1884	U+609A:悚
1885	U+6089:悉
1886	U+609B:悛
1887	U+609D:悝
1888	U+609E:悞
1889	U+609F:悟
1890	U+60A0:悠
1891	U+60A3:患
1892	U+60A4:悤
1893	U+6081:悁
1894	U+60B1:悱
1895	U+60EA:惪
1896	U+60B2:悲
1897	U+60B4:悴
1898	U+60B5:悵
1899	U+60B6:悶
<a id="s19"></a>
1900	U+60B8:悸
1901	U+60BB:悻
1902	U+60BC:悼
1903	U+60BD:悽
1904	U+60BE:悾
1905	U+60C4:惄
1906	U+60C5:情
1907	U+60C6:惆
1908	U+60C7:惇
1909	U+60CE:惎
1910	U+60D1:惑
1911	U+60D3:惓
1912	U+60D5:惕
1913	U+60D8:惘
1914	U+60D9:惙
1915	U+60DA:惚
1916	U+60DB:惛
1917	U+60DC:惜
1918	U+60DD:惝
1919	U+60DF:惟
1920	U+60E0:惠
1921	U+60E1:惡	<span class="china1">U+6076:恶</span>
1922	U+60B0:悰
1923	U+60CB:惋
1924	U+60F0:惰
1925	U+60F1:惱	<span class="china1">U+607C:恼</span>
1926	U+60F2:惲
1927	U+60F3:想
1928	U+60F4:惴
1929	U+60F6:惶
1930	U+60F8:惸
1931	U+60F9:惹
1932	U+60FA:惺
1933	U+60FB:惻
1934	U+6100:愀
1935	U+6101:愁
1936	U+6106:愆
1937	U+6108:愈
1938	U+6109:愉
1939	U+610A:愊
1940	U+610D:愍
1941	U+610E:愎
1942	U+610F:意
1943	U+6112:愒
1944	U+6114:愔
1945	U+6115:愕
1946	U+611A:愚
1947	U+611B:愛	<span class="china1">U+7231:爱</span>
1948	U+611C:愜
1949	U+611F:感
1950	U+6120:愠
1951	U+6127:愧
1952	U+6164:慤
1953	U+612B:愫
1954	U+612C:愬
1955	U+6134:愴
1956	U+6137:愷
1957	U+613C:愼
1958	U+613E:愾
1959	U+613F:愿
1960	U+6142:慂
1961	U+6144:慄
1962	U+6146:慆
1963	U+6147:慇
1964	U+6148:慈
1965	U+614A:慊
1966	U+614B:態	<span class="china1">U+6001:态</span>
1967	U+614C:慌
1968	U+6141:慁
1969	U+6153:慓
1970	U+6155:慕
1971	U+6158:慘	<span class="china1">U+60E8:惨</span>
1972	U+6159:慙
1973	U+615D:慝
1974	U+615A:慚
1975	U+615F:慟
1976	U+6162:慢
1977	U+6163:慣
1978	U+6169:慩
1979	U+6167:慧
1980	U+6168:慨
1981	U+616B:慫
1982	U+616E:慮	<span class="china1">U+8651:虑</span>
1983	U+6170:慰
1984	U+6173:慳
1985	U+6174:慴
1986	U+6175:慵
1987	U+6176:慶	<span class="china1">U+5E86:庆</span>
1988	U+6177:慷
1989	U+617C:慼
1990	U+617E:慾
1991	U+6181:憁
1992	U+6182:憂	<span class="china1">U+5FE7:忧</span>
1993	U+6165:慥
1994	U+618A:憊
1995	U+6190:憐	<span class="china1">U+601C:怜</span>
1996	U+6191:憑
1997	U+6194:憔
1998	U+619A:憚
1999	U+618E:憎
</pre>
<p class="divcenter">上一頁　<a href="cccode02.php" rel="next">下一頁</a><br />
<a href="cccode.php">返回上一目錄</a><br />
<a href="../index.php">返回主網頁</a></p>
<div class="divcenter">
<span style="font-size:83%;" class="cScreen">
<a href="javascript:chgfontsize(+1);">[放大字體]</a>
<a href="javascript:chgfontsize(-1);">[縮小字體]</a>
<a href="javascript:chgfontsize('O');">[原來大小]</a>
<br /></span>
<script type="text/javascript" src="../js/clockto.js"></script><br />
<span style="font-size:83%;font-style:italic;"><img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIGJhc2VQcm9maWxlPSJmdWxsIiB2aWV3Qm94PSIwIDAgMTAwIDIwMCIgd2lkdGg9IjEwMCIgaGVpZ2h0PSIyMDAiPgo8ZyBmaWxsPSJibGFjayI+CjxwYXRoIGQ9Ik0gMTUuNCAxMTYuMiBMIDE3LjcgMTIzLjUgTCAyMC43IDEzMC4wIEwgMjQuNSAxMzUuNiBMIDI4LjcgMTQwLjQgTCAzMy41IDE0NC4yIEwgMzguNiAxNDYuOSBMIDQ0LjEgMTQ4LjYgTCA0OS45NSAxNDkuMTk0OTE1Mjk0NjQ3MjIgTCA1NS44IDE0OC42IEwgNjEuMyAxNDYuOSBMIDY2LjQgMTQ0LjIgTCA3MS4yIDE0MC40IEwgNzUuNCAxMzUuNiBMIDc5LjIgMTMwLjAgTCA4Mi4yIDEyMy41IEwgODQuNSAxMTYuMiBMIDg2LjAgMTA4LjQgTCA4Ni41IDEwMC4wIEwgODYuMCA5MS41IEwgODQuNSA4My43IEwgODIuMiA3Ni40IEwgNzkuMiA2OS45IEwgNzUuNCA2NC4zIEwgNzEuMiA1OS41IEwgNjYuNCA1NS43IEwgNjEuMyA1My4wIEwgNTUuOCA1MS4zIEwgNTAuMCA1MC43IEwgNDQuMSA1MS4zIEwgMzguNiA1My4wIEwgMzMuNSA1NS43IEwgMjguNyA1OS41IEwgMjQuNSA2NC4zIEwgMjAuNyA2OS45IEwgMTcuNyA3Ni40IEwgMTUuNCA4My43IEwgMTMuOSA5MS41IEwgMTMuNSAxMDAuMCBMIDEzLjkgMTA4LjQgWiBNIDM1LjkgNzcuNiBMIDM1LjEgNzguNSBMIDM0LjIgNzkuMyBMIDMzLjQgODAuMSBMIDMyLjUgODAuOSBMIDMxLjUgODEuNyBMIDMwLjYgODIuNSBMIDI5LjYgODMuMyBMIDI5LjIgODQuMyBMIDI3LjUgODMuNiBMIDI3LjggODIuNiBMIDI3LjUgODEuNCBMIDI2LjkgNzcuOCBMIDI2LjggNzYuNiBMIDI2LjYgNzUuNCBMIDI2LjUwMDA3NjAwNzg0MzAxNyA3NC4zMDA4MzU4OTU1MzgzMyBMIDI2LjEgNzQuNCBMIDI2LjQgNzMuMiBMIDI2LjQwNTcxNDMyMTEzNjQ3NSA3My4xNjg1NzE0NzIxNjc5NyBMIDI2LjMgNzEuOSBMIDI2LjYyMjYyMDc3MzMxNTQzIDcyLjAxNzA1NzEzMjcyMDk1IEwgMjYuOSA3MS4wIEwgMjcuMSA2OS45IEwgMjcuNCA2OC43IEwgMjcuOCA2Ny42IEwgMjguMSA2Ni41IEwgMjguNSA2NS4zIEwgMjguOSA2NC4yIEwgMjguNyA2My4yIEwgMzAuNCA2Mi43IEwgMzAuNyA2My43IEwgMzIuNzcwMjcwMjUyMjI3NzggNjUuNzcwMjcwMjUyMjI3NzkgTCAzNS4wIDY0LjcgTCAzNy42IDYzLjkgTCA0MC4zIDYzLjUgTCA0Mi45IDYzLjQgTCA0NS41IDYzLjcgTCA0OC4xIDY0LjIgTCA0OC42MzQxODE3ODU1ODM0OSA2NC40MDU0NTQ1NDAyNTI2OSBMIDUxLjIgNjQuMSBMIDU1LjYgNjQuNiBMIDU5LjkgNjYuMiBMIDY0LjAgNjguOCBMIDY3LjggNzIuNCBMIDcxLjAgNzYuOSBMIDczLjcgODIuMiBMIDc1LjcgODguNCBMIDc3LjAgOTUuNCBMIDc3LjQ0ODEzNjgwNjQ4ODA0IDEwMi4zMDEzMDc0ODc0ODc3OSBMIDc3LjUgMTAyLjMgTCA3Ny40Njc2OTQ1Njg2MzQwMyAxMDIuNjAyNDk2MzM3ODkwNjMgTCA3Ny41IDEwMy4xIEwgNzcuNDE0NzkyNTM3Njg5MjEgMTAzLjA5Nzg1MTk0Mzk2OTczIEwgNzYuNCAxMTIuNiBMIDczLjQgMTIxLjQgTCA2OC43IDEyOC41IEwgNjIuNyAxMzMuNyBMIDU1LjcgMTM2LjYgTCA0OC40IDEzNy4xIEwgNDEuMiAxMzUuMSBMIDM0LjYgMTMwLjcgTCAyOS4wIDEyMy45IEwgMjUuMzUxMzUxMzU2NTA2MzUgMTE2LjUyMTYyMTYwODczNDE0IEwgMjQuNSAxMTQuOSBMIDI0LjUzOTE5MDU3ODQ2MDY5NCAxMTQuODc5MjUyMDUyMzA3MTIgTCAyNC41IDExNC44IEwgMjUuMzUgMTE0LjQ1IEwgMjYuMiAxMTQuMCBMIDMxLjUgMTIwLjYgTCAzNy4xIDEyNC44IEwgNDIuNiAxMjYuOSBMIDQ3LjcgMTI3LjQgTCA1Mi40IDEyNi40IEwgNTYuNiAxMjQuMCBMIDYwLjEgMTIwLjUgTCA2Mi44IDExNS43IEwgNjQuNSAxMDkuNyBMIDY1LjAgMTAyLjUgTCA2NS4wMDQ2MTU0MDIyMjE2NyAxMDIuNSBMIDY1LjEgOTYuMyBMIDY0LjcgOTAuNCBMIDYzLjggODUuNCBMIDYyLjUgODEuMCBMIDYwLjggNzcuMiBMIDU4LjcgNzQuMCBMIDU2LjMgNzEuNCBMIDUzLjYgNjkuMyBMIDUwLjUgNjcuNSBMIDUwLjI3ODQ4MTAwNjYyMjMxNCA2Ny40MzAzNzk3NzIxODYyOCBMIDQ4LjAgNjguMCBMIDQ1LjkgNjguNiBMIDQ0LjAgNjkuNCBMIDQyLjQgNzAuNCBMIDQxLjAgNzEuNSBMIDM5LjkgNzIuNiBMIDM4LjkgNzMuOSBMIDM4LjEgNzUuMyBMIDM3LjMgNzYuOCBMIDM1Ljk4ODUyNDYyNzY4NTU1IDc3LjUyMTMxMTQ3Mzg0NjQ0IFogTSA5Ni4yIDExOS4xIEwgOTMuNCAxMjcuOCBMIDg5LjYgMTM1LjggTCA4NS4wIDE0Mi45IEwgNzkuNCAxNDkuMSBMIDczLjAgMTU0LjIgTCA2NS45IDE1OC4wIEwgNTguMiAxNjAuNCBMIDUwLjAgMTYxLjIgTCA0OS45NSAxNTUuMiBMIDQ5LjkgMTYxLjIgTCA0MS43IDE2MC40IEwgMzQuMCAxNTguMCBMIDI2LjkgMTU0LjIgTCAyMC41IDE0OS4xIEwgMTQuOSAxNDIuOSBMIDEwLjMgMTM1LjggTCA2LjUgMTI3LjggTCAzLjcgMTE5LjEgTCAyLjAgMTA5LjggTCAxLjUgMTAwLjAgTCAyLjAgOTAuMSBMIDMuNyA4MC44IEwgNi41IDcyLjEgTCAxMC4zIDY0LjEgTCAxNC45IDU3LjAgTCAyMC41IDUwLjggTCAyNi45IDQ1LjcgTCAzNC4wIDQxLjkgTCA0MS43IDM5LjUgTCA1MC4wIDM4LjcgTCA1OC4yIDM5LjUgTCA2NS45IDQxLjkgTCA3My4wIDQ1LjcgTCA3OS40IDUwLjggTCA4NS4wIDU3LjAgTCA4OS42IDY0LjEgTCA5My40IDcyLjEgTCA5Ni4yIDgwLjggTCA5Ny45IDkwLjEgTCA5OC41IDEwMC4wIEwgOTcuOSAxMDkuOCBaICIgLz4KPC9nPgo8L3N2Zz4=" alt="Copyleft &#127279;" style="height:1.2em;vertical-align:-15%;"/> 2004-2021 <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIGJhc2VQcm9maWxlPSJmdWxsIiAgd2lkdGg9IjE2NSIgaGVpZ2h0PSIzMCI+PHRleHQgeD0iMCIgeT0iMjAiIGZpbGw9ImJsYWNrIiBmb250LXN0eWxlPSJpdGFsaWMiPuKAimtsbmVhc3RAeWFob28uY29tLmhrPC90ZXh0Pjwvc3ZnPg==" alt="My Email" style="height:1.8em;vertical-align:-50%;"/>
本頁更新日期：1 September 2018</span>
<!--<p><span style="font-size:83%;padding-left:2em;vertical-align:middle;">&#26412;&#32178;&#26377;1279115&#20154;&#28687;&#35261;&#12290;&#26412;&#38913;&#21443;&#35264;&#20154;&#25976;&#65306;66506</span></p>-->
</div>
</div>
<div id="Menu">
<p style="text-indent:0.8em;"><a href="javascript:chgfontsize(+1);">[放大字體]</a></p>
<p style="margin-top:-0.5em;text-indent:0.8em;"><a href="javascript:chgfontsize(-1);">[縮小字體]</a></p>
<p style="margin-top:-0.5em;text-indent:0.8em;"><a href="javascript:chgfontsize('O');">[原來大小]</a></p>
<div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 125x125 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:125px;height:125px"
     data-ad-client="ca-pub-0927799012174491"
     data-ad-slot="0153402065"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div><div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 0822248218 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:120px;height:600px"
     data-ad-client="ca-pub-0927799012174491"
     data-ad-slot="0822248218"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<p><a href="http://www.dnsexit.com/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAMAAAA3Z0MzAAADAFBMVEUzM2b/5Mj6dRKhoaH/sGH8ji5MTHmzs8b/0qX8fhH//Pn7exllZYz/w4f/okTm5uyMjKnNzdn/ixj/uXP/3rxzc5Y/P2//9/D+xpH+pFL/nTqlpbz7fR7/797/kSOamrPZ2eL/hw/9rmpZWYN/f5/9voj/qlX9lz/////9xpz/mTO/v8/z8/by8vX/1qz+t3f/iRL/jx7/8eb+zaH/6dj8nlb8hCH/lCj6dxb/4cP/pUr9plv/tm3/rVr8hyn/smT/ly6AgKDZ2eP/9Oj8hBz9m0RAQHD/+vX/5sz/zJn/7Nj/v37/ypb/2bT90K76exsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNcF5PAAAACXBIWXMAAA7EAAAOxAGVKw4bAAACNElEQVR42sXVDXOaQBAG4NUoKIVY1JSKQXKm2m3URpq0KaQqjSk2X+3//zfdPWHEKn7MOJN39BBmfLi7XQY4OnzgCA+d1zP9kSe2xRv5+5ilsFArNOywNdzMlnY3fbtWmzTsi1Z121z9nc3RDyKPdyDFaLtpmhU+iNqke3zRaAQcEQY2/dsOQkE/gnnCBF0ygfNhgOiCS6c6IJ5FdOktm0zexBUQNlqe8Cy0BfoivrmRbYLOZjSYmwoo5wAmMUxWfTQ4XImS/LJpGCV0DCNYbxLXi0hwgSdK5hmc8B1+kknkcOhj0jQWGjxXNoUI5JhpYpOWSqYiTZPNiquSyeTCFEa82sSs5j4/dW+G602TRhcUUNnsA5w3B3ILq4s+kZNy0BFp8xFxOnXqT9kmqXI/XUhqFPeeT3meL97xUqZ4kIT2sM6sSNPUQWUTewrIzU3MrLWLrkVXppMNazfpIE3EuxPe3P/MEHGCGKbMloMaolVvrTF7VGUyaeURoKr3ZI8tTNnennjBZ+qll3Td6+jQVLXf9qpJi5amSmumJqC6D9KmTBDEPR+kzEutcKVxBZfNd7pOTd6XJrU70OaC7ioMl2XaHZliu3NLZ7eddpk+5XKRx4/OffGalC+rz5Fyh3NT5enxbCGiJ/5vfmvG+fwfLv2SaXL6XHs5miZXyHWbfPI1v0s+rZibcn36nfNmKaep3FPGj/u9O3LFbxkZJ/mV0/Z9x11dNjbmvTWbzV7/vbm3efj8Ayq6EYOVM/vXAAAAAElFTkSuQmCC" alt="dnsExit.Com" /></a></p>
<!--<p style="margin-top:-0.5em;"><a href="http://www.prchecker.info/" title="PRchecker.info" rel="nofollow"><img src="http://pr-v2.prchecker.info/getpr.v2.php?codex=aHR0cDovL2NvZGUud2ViLmlkdi5oaw==&amp;tag=1" alt="PRchecker.info" /></a></p>-->
<script type="text/javascript">
<!--
if(getCookie('fontsize') !== false) {
	document.getElementById('bodyContent').style.fontSize=getCookie('fontsize') + "em";
}
//-->
</script>
</div>
</body>
</html>
