#!/usr/bin/env python
import sys, os.path
import re

napat = re.compile(r'\W')

def norm(s):
	return napat.sub('', s).lower()

assert __name__ == '__main__'
if len(sys.argv) < 2:
	f = sys.stdin
else:
	f = open(sys.argv[1])
page = 0
lastword = None
for line in f:
	p = line.index('Page') + 4
	q = line.index(',', p)
	n = int(line[p:q])
	p = line.index(' to ', q) + 4
	word = norm(line[q+1:p-4].strip())
	if page:
		try:
			assert n == page + 1
			assert word >= lastword
		except:
			print >> sys.stderr, line.strip()
			raise
	page = n
	lastword = norm(line[p:].strip())
print 'Pass'
