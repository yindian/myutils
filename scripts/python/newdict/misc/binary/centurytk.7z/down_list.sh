#!/bin/bash
WORD=zyzzogeton
UA="Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)"
while [ -n "$WORD" ]; do
	wget -nc --max-redirect=0 -U "$UA" -x "http://triggs.djvu.org/century-dictionary.com/wnph-chw.php?query=$WORD&type=dicts"
	WORD=$(echo "$WORD" | sed 's/\x27/%27/g;s/%\([0-9A-F][0-9A-F]\)/\\\\\x\1/g' | xargs echo -e | sed 's=/=%2F=g')
	if [ ! -e "triggs.djvu.org/century-dictionary.com/wnph-chw.php?query=$WORD&type=dicts" ]; then
		echo "triggs.djvu.org/century-dictionary.com/wnph-chw.php?query=$WORD&type=dicts not downloaded"
		sleep 20
		continue
	fi
	NEWWORD=`grep -w djvuopts "triggs.djvu.org/century-dictionary.com/wnph-chw.php?query=$WORD&type=dicts" | head -1 | sed 's/^.* to //'`
	if [ -z "$NEWWORD" ]; then
		#rm "triggs.djvu.org/century-dictionary.com/wnph-chw.php?query=$WORD&type=dicts"
		echo "$WORD not found"
		WORD=`python nextword.py "$WORD"`
		if [ -z "$WORD" ]; then
			echo "Done. $?"
			break
		fi
	else
		WORD=`python nextword.py "$NEWWORD"`
		if [ -z "$WORD" ]; then
			echo "Done. $? NEWWORD: $NEWWORD"
			break
		fi
	fi
	#read -t 1
done
