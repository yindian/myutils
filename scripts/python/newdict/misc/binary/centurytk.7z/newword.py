#!/usr/bin/env python
import sys
def nextword(s):
	if s:
		if s[-1] == 'z':
			return nextword(s[:-1])
		return s[:-1] + min(chr(ord(s[-1]) + 5), 'z')
	return ''
assert __name__ == '__main__'
assert len(sys.argv) == 2
s = sys.argv[1].lower()
print nextword(s)
