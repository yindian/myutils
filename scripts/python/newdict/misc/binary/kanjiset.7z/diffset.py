#!/usr/bin/env python
import sys, os.path

assert __name__ == '__main__'

if len(sys.argv) < 3:
	print "Usage: %s set1.txt set2.txt" % (os.path.basename(sys.argv[0]),)
	print "Each line contains one set element string. Comment (#) allowed"
	print "Print out elements that are in set1 but not in set2"
	sys.exit(0)

f = open(sys.argv[1], 'r')
dict1 = {}
for line in f:
	elem = line[:line.find('#')].strip()
	if elem:
		try:
			assert not dict1.has_key(elem)
		except:
			print >> sys.stderr, 'Duplicate element', elem
			raise
		dict1[elem] = line
set1 = set(dict1.keys())
f.close()
f = open(sys.argv[2], 'r')
set2 = set(filter(None, [s[:s.find('#')].strip() for s in f]))
f.close()
diff = set1.difference(set2)
for elem in sorted(list(diff)):
	sys.stdout.write(dict1[elem])
