#!/usr/bin/env python
import sys, os.path

assert __name__ == '__main__'

if len(sys.argv) < 2:
	print "Usage: %s set.txt" % (os.path.basename(sys.argv[0]),)
	sys.exit(0)

f = open(sys.argv[1], 'r')
dict1 = {}
for line in f:
	elem = line[:line.find('#')].strip()
	if elem:
		try:
			assert not dict1.has_key(elem)
		except:
			print >> sys.stderr, 'Duplicate element', elem
			raise
		if line.find('#') < 0:
			dict1[elem] = 1
		else:
			dict1[elem] = filter(None, line.split('#'))[1].strip()
f.close()
for elem in sorted(dict1.keys()):
	if type(dict1[elem]) == type(''):
		try:
			assert dict1.has_key(dict1[elem])
		except:
			print >> sys.stderr, 'Unresolved %s -> %s' % (elem,
					dict1[elem])
			raise
