#!/usr/bin/env python
import sys, os.path, string

assert __name__ == '__main__'

if len(sys.argv) < 3:
	print "Usage: %s ksimple.txt fullset.txt" % (os.path.basename(sys.argv[0]),)
	sys.exit(0)

f = open(sys.argv[2], 'r')
simpset = set(filter(None, map(string.strip, filter(lambda s:s.find('#') < 0, f))))
f.close()

f = open(sys.argv[1], 'r')
fwspace = u'\u3000'.encode('utf-8')
mapped = {}
while True:
	trad = f.readline()
	if not trad:
		break
	simp = f.readline()
	ryak = f.readline()
	assert trad and simp and ryak
	trad, simp, ryak = map(string.rstrip, (trad, simp, ryak))
	trad, simp, ryak = map(lambda s: s.split('\t')[1:], (trad, simp, ryak))
	assert len(trad) == len(simp) == len(ryak)
	for i in xrange(len(trad)):
		assert trad[i] != fwspace
		if trad[i] in simpset:
			try:
				assert simp[i] == fwspace
			except:
				try:
					assert simp[i] in simpset
				except:
					#print >> sys.stderr, 'Warning: trad %s in set but simp %s not' % (trad[i], simp[i])
					if not mapped.has_key(simp[i]+ trad[i]):
						print '%s#%s'% (simp[i],trad[i])
						mapped[simp[i]+ trad[i]] = 1
			if ryak[i] != fwspace and ryak[i] not in simpset:
				if not mapped.has_key(ryak[i] + trad[i]):
					print '%s#%s' % (ryak[i], trad[i])
					mapped[ryak[i] + trad[i]] = 1
		elif simp[i] in simpset:
			if not mapped.has_key(trad[i] + simp[i]):
				print '%s#%s' % (trad[i], simp[i])
				mapped[trad[i] + simp[i]] = 1
			if ryak[i] != fwspace and ryak[i] not in simpset:
				if not mapped.has_key(ryak[i] + simp[i]):
					print '%s#%s' % (ryak[i], simp[i])
					mapped[ryak[i] + simp[i]] = 1
		elif ryak[i] in simpset:
			print '%s#%s' % (trad[i], ryak[i])
			if simp[i] != fwspace and simp[i] not in simpset:
				if not mapped.has_key(simp[i] + ryak[i]):
					print '%s#%s' % (simp[i], ryak[i])
					mapped[simp[i] + ryak[i]] = 1
		else:
			print >> sys.stderr, 'Warning: %s %s %s not in set' % (trad[i], simp[i], ryak[i])
f.close()
