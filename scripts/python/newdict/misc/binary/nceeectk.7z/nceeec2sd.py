#!/usr/env/bin python
import sys, os.path
import glob
import string
import re
import urllib

linkpat = re.compile(r'<A href="#" onclick="javascript:gotoPage[^>]*WoRd=([^>"&]*)[^>]*>')
linkrepl = lambda m: '<A href="bword://%s">' % (urllib.unquote(m.group(1).replace('+', ' ')),)
uptagpat = re.compile(r'<(/?)([A-Z]+)([^>]*)>')
uptagrepl = lambda m: '<%s%s%s>' % (m.group(1), m.group(2).lower(), m.group(3))
srcpat = re.compile(r'src="?([^"> ]+)"?', re.I)
srcrepl = lambda m: 'src="%s"' % (os.path.basename(m.group(1)),)

def formatmean(mean, word):
	# .replace('SRC="../images/KK/', 'SRC="')
	return '<table>%s</table>' % (srcpat.sub(srcrepl, linkpat.sub(linkrepl, mean)),)

assert __name__ == '__main__'

flist = glob.glob('www.onlinedict.com/servlet/*')
flist.sort(key=string.lower)

for fname in flist:
	f = open(fname)
	buf = f.read()
	f.close()
	try:
		p = buf.index('<tr bgcolor="moccasin">')
		p = buf.index('<B>', p) + 3
		q = buf.index('</B>', p)
		word = buf[p:q]
		p = buf.index('<tr>', q)
		try:
			q = buf.index('<!-- AddThis Button BEGIN -->', p)
		except:
			q = buf.index('gotoSuggestion', p)
			q = buf.index('<a href', p, q)
		mean = buf[p:q]
		assert mean.endswith('<tr><td colspan="20">')
		mean = mean[:-21]
	except:
		print >> sys.stderr, 'Error processing', fname
		raise
	mean = formatmean(mean, word)
	print '%s\t%s' % (word, mean)
