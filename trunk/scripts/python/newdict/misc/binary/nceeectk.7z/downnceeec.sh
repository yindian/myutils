#!/bin/bash
#WORD="MobiDictLookup14?WoRd=a&example=true&phrase=true"
#WORD="MobiDictLookup14?WoRd=aiguillette&example=true&phrase=true"
#WORD="MobiDictLookup14?WoRd=Albert+Schweitzer&example=true&phrase=true"
#WORD="MobiDictLookup14?WoRd=auk&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Bennett&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=bioinstrumentation&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=byssi&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=cad&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=calender&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=con&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=dewlap&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=element&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=friend&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Georges+Bizet&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Hanoi&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=hare&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=huzza&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Isabel&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=John+Birch+Society&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=lumber&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=mosquito&example=true&phrase=true&from=prev"
WORD="MobiDictLookup14?WoRd=moss&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=nifty&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=oscillate&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=rapid&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=remediable&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Russell&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=russet&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=Thomas+Mann&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=trace&example=true&phrase=true&from=prev"
#WORD="MobiDictLookup14?WoRd=webbing&example=true&phrase=true&from=prev"
UA="Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16"
while [ -n "$WORD" ]; do
	wget -nc --max-redirect=0 -U "$UA" -S -x "http://www.onlinedict.com/servlet/$WORD"
	WORD=$(echo "$WORD" | sed 's/\x27/%27/g;s/%\([0-9A-F][0-9A-F]\)/\\\\\x\1/g' | xargs echo -e | sed 's=/=%2F=g')
	if [ ! -e "www.onlinedict.com/servlet/$WORD" ]; then
		echo "www.onlinedict.com/servlet/$WORD not downloaded"
		sleep 20
		continue
	fi
	WORD=`sed 's/gotoPage([^)]*)/\n&\n/g' "www.onlinedict.com/servlet/$WORD" | sed -n '/gotoPage/{/from=prev/{s=^[^,]*,.\(.*\).)$=\1=;p}}'`
	read -t 3
done
