#!/usr/bin/env python
import sys, os.path, string

assert __name__ == '__main__'

if len(sys.argv) < 3:
	print "Usage: %s xxg2.txt fullset.txt" % (os.path.basename(sys.argv[0]),)
	sys.exit(0)

f = open(sys.argv[2], 'r')
#simpset = set(filter(None, map(string.strip, filter(lambda s:s.find('#') < 0, f))))
simpset = set(filter(None, map(string.strip, [s.split('#')[0] for s in f])))
f.close()

f = open(sys.argv[1], 'r')
visited = set()
for line in f:
	ar = list(set(line[:line.find('\t')].decode('utf-8').split(u'|')))
	simp = None
	for i in xrange(len(ar)):
		if 0x3400 <= ord(ar[i]) < 0xE000 and ar[i].encode('utf-8') in simpset:
			simp = ar[i]
			break
	if simp is not None:
		for i in xrange(len(ar)):
			if 0x3400 <= ord(ar[i]) < 0xE000 and not ar[i]+simp in visited and ar[i].encode('utf-8') not in simpset:
				print (u'%s#%s' % (ar[i], simp)).encode('utf-8')
				visited.add(ar[i]+simp)
f.close()
